# LUANDA RP — mapa urbano 3D

Projeto web de roleplay para PC e Android, construído com React, Vite e Three.js.

## O que foi acrescentado nesta versão

- Malha de ruas secundárias para ligar Centro, Maianga, Viana e Talatona.
- Passeios urbanos e novas rotundas de distribuição de trânsito.
- Aeroporto com pista marcada, terminal e torre de controlo.
- Estádio 11 de Novembro em 3D.
- Zona portuária com terminal e gruas.
- Quartel dos Bombeiros, oficina mecânica e mercado popular.
- Novos pontos de interação para aeroporto, estádio, porto, bombeiros, oficina e mercado.
- Colisores dos edifícios criados através do construtor existente, para respeitar a navegação do jogador.

## Executar localmente

Requisitos: Node.js 20 ou superior.

```bash
npm install
npm run dev
```

Abrir o endereço local apresentado pelo Vite no navegador.

## Verificar a compilação

```bash
npm run build
npm run lint
```

> A compilação completa ainda precisa de ser executada no computador de desenvolvimento, onde as dependências possam ser instaladas. O ficheiro `cityBuilder.ts` foi verificado quanto a erros de sintaxe TypeScript; isso não substitui o teste completo do jogo.

## Estado e limitações

Esta versão amplia o cenário procedural e os pontos de interação locais. Não implementa ainda sincronização multiplayer real, tráfego aéreo/navios, interiores completos, nem um GPS com navegação por rotas. Esses sistemas precisam de implementação e testes próprios.
