/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { soundFx } from '../audio/soundFx';
import { AnimationState, PlayerCustomization, PlayerStats } from '../types';

export interface PlayerControlsInput {
  forward: boolean;
  backward: boolean;
  left: boolean;
  right: boolean;
  sprint: boolean;
  jump: boolean;
  interact: boolean;
}

export class PlayerCharacter {
  public mesh: THREE.Group;
  public position: THREE.Vector3 = new THREE.Vector3(0, 0, 0);
  public velocity: THREE.Vector3 = new THREE.Vector3();
  public rotationY = 0;
  public isGrounded = true;
  public animState: AnimationState = 'idle';

  // Componentes visuais para animação
  private torsoGroup!: THREE.Group;
  private headMesh!: THREE.Mesh;
  private hairMesh!: THREE.Mesh;
  private leftArmGroup!: THREE.Group;
  private rightArmGroup!: THREE.Group;
  private leftLegGroup!: THREE.Group;
  private rightLegGroup!: THREE.Group;

  // Materiais personalizáveis
  private skinMat!: THREE.MeshStandardMaterial;
  private shirtMat!: THREE.MeshStandardMaterial;
  private pantsMat!: THREE.MeshStandardMaterial;
  private shoesMat!: THREE.MeshStandardMaterial;
  private hairMat!: THREE.MeshStandardMaterial;

  // Estado interno de animação
  private animTimer = 0;
  private footstepTimer = 0;
  private jumpVelocity = 0;
  private gravity = -24;
  private targetAngle = 0;

  constructor(customization: PlayerCustomization) {
    this.mesh = new THREE.Group();
    this.mesh.name = 'PlayerCharacter';
    this.buildBody(customization);
  }

  private buildBody(cust: PlayerCustomization) {
    // 1. Materiais
    this.skinMat = new THREE.MeshStandardMaterial({
      color: cust.skinTone || '#4a2c17',
      roughness: 0.7,
      metalness: 0.05,
    });
    this.shirtMat = new THREE.MeshStandardMaterial({
      color: cust.shirtColor || '#dc2626', // Vermelho vivo
      roughness: 0.5,
      metalness: 0.1,
    });
    this.pantsMat = new THREE.MeshStandardMaterial({
      color: cust.pantsColor || '#1e3a8a', // Azul escuro jeans
      roughness: 0.6,
      metalness: 0.05,
    });
    this.shoesMat = new THREE.MeshStandardMaterial({
      color: cust.shoesColor || '#ffffff', // Ténis branco
      roughness: 0.4,
      metalness: 0.1,
    });
    this.hairMat = new THREE.MeshStandardMaterial({
      color: cust.hairColor || '#171717',
      roughness: 0.9,
    });

    // 2. Grupo Torso & Tronco (Central)
    this.torsoGroup = new THREE.Group();
    this.torsoGroup.position.y = 0.95; // Centro da bacia / tronco

    // Torso (Camisa / Peito)
    const torsoGeo = new THREE.BoxGeometry(0.52, 0.65, 0.32);
    const torsoMesh = new THREE.Mesh(torsoGeo, this.shirtMat);
    torsoMesh.position.y = 0.32;
    torsoMesh.castShadow = true;
    this.torsoGroup.add(torsoMesh);

    // Emblema no peito (pequena bandeira angolana no coração)
    const badgeGeo = new THREE.PlaneGeometry(0.1, 0.07);
    const badgeMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.3 });
    const badgeMesh = new THREE.Mesh(badgeGeo, badgeMat);
    badgeMesh.position.set(0.14, 0.45, 0.17);
    this.torsoGroup.add(badgeMesh);

    // Pescoço
    const neckGeo = new THREE.CylinderGeometry(0.1, 0.12, 0.15, 12);
    const neckMesh = new THREE.Mesh(neckGeo, this.skinMat);
    neckMesh.position.y = 0.68;
    this.torsoGroup.add(neckMesh);

    // Cabeça
    const headGeo = new THREE.BoxGeometry(0.32, 0.36, 0.32);
    this.headMesh = new THREE.Mesh(headGeo, this.skinMat);
    this.headMesh.position.y = 0.92;
    this.headMesh.castShadow = true;
    this.torsoGroup.add(this.headMesh);

    // Cabelo / Penteado estilizado
    const hairGeo = new THREE.BoxGeometry(0.35, 0.16, 0.35);
    this.hairMesh = new THREE.Mesh(hairGeo, this.hairMat);
    this.hairMesh.position.y = 0.18;
    this.headMesh.add(this.hairMesh);

    // Olhos / Óculos escuros estilosos de Luanda
    const shadesGeo = new THREE.BoxGeometry(0.28, 0.08, 0.06);
    const shadesMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.1, metalness: 0.9 });
    const shadesMesh = new THREE.Mesh(shadesGeo, shadesMat);
    shadesMesh.position.set(0, 0.04, 0.17);
    this.headMesh.add(shadesMesh);

    // 3. Braços Articulados (Ombro como pivô)
    // Braço Esquerdo
    this.leftArmGroup = new THREE.Group();
    this.leftArmGroup.position.set(-0.35, 0.55, 0);

    const sleeveGeo = new THREE.BoxGeometry(0.16, 0.22, 0.18);
    const sleeveL = new THREE.Mesh(sleeveGeo, this.shirtMat);
    sleeveL.position.y = -0.11;
    this.leftArmGroup.add(sleeveL);

    const armGeo = new THREE.BoxGeometry(0.14, 0.42, 0.14);
    const armL = new THREE.Mesh(armGeo, this.skinMat);
    armL.position.y = -0.32;
    armL.castShadow = true;
    this.leftArmGroup.add(armL);

    this.torsoGroup.add(this.leftArmGroup);

    // Braço Direito
    this.rightArmGroup = new THREE.Group();
    this.rightArmGroup.position.set(0.35, 0.55, 0);

    const sleeveR = new THREE.Mesh(sleeveGeo, this.shirtMat);
    sleeveR.position.y = -0.11;
    this.rightArmGroup.add(sleeveR);

    const armR = new THREE.Mesh(armGeo, this.skinMat);
    armR.position.y = -0.32;
    armR.castShadow = true;
    this.rightArmGroup.add(armR);

    this.torsoGroup.add(this.rightArmGroup);

    // 4. Pernas Articuladas (Quadril como pivô)
    // Perna Esquerda
    this.leftLegGroup = new THREE.Group();
    this.leftLegGroup.position.set(-0.16, 0.95, 0);

    const legGeo = new THREE.BoxGeometry(0.2, 0.72, 0.2);
    const legL = new THREE.Mesh(legGeo, this.pantsMat);
    legL.position.y = -0.36;
    legL.castShadow = true;
    this.leftLegGroup.add(legL);

    // Calçado / Ténis esquerdo
    const shoeGeo = new THREE.BoxGeometry(0.22, 0.16, 0.32);
    const shoeL = new THREE.Mesh(shoeGeo, this.shoesMat);
    shoeL.position.set(0, -0.74, 0.05);
    shoeL.castShadow = true;
    this.leftLegGroup.add(shoeL);

    this.mesh.add(this.leftLegGroup);

    // Perna Direita
    this.rightLegGroup = new THREE.Group();
    this.rightLegGroup.position.set(0.16, 0.95, 0);

    const legR = new THREE.Mesh(legGeo, this.pantsMat);
    legR.position.y = -0.36;
    legR.castShadow = true;
    this.rightLegGroup.add(legR);

    // Calçado / Ténis direito
    const shoeR = new THREE.Mesh(shoeGeo, this.shoesMat);
    shoeR.position.set(0, -0.74, 0.05);
    shoeR.castShadow = true;
    this.rightLegGroup.add(shoeR);

    this.mesh.add(this.rightLegGroup);

    this.mesh.add(this.torsoGroup);

    // Configuração de escala e sombra
    this.mesh.scale.setScalar(cust.heightScale || 1.0);
  }

  public updateCustomization(cust: PlayerCustomization) {
    if (this.skinMat) this.skinMat.color.set(cust.skinTone);
    if (this.shirtMat) this.shirtMat.color.set(cust.shirtColor);
    if (this.pantsMat) this.pantsMat.color.set(cust.pantsColor);
    if (this.shoesMat) this.shoesMat.color.set(cust.shoesColor);
    if (this.hairMat) this.hairMat.color.set(cust.hairColor);
    if (this.mesh && cust.heightScale) {
      this.mesh.scale.setScalar(cust.heightScale);
    }
  }

  public update(
    delta: number,
    input: PlayerControlsInput,
    cameraYaw: number,
    colliders: THREE.Box3[],
    stats: PlayerStats
  ) {
    // 1. Determina Direção de Movimento no Plano Horizontal a partir da Câmera
    let moveX = 0;
    let moveZ = 0;

    if (input.forward) moveZ -= 1;
    if (input.backward) moveZ += 1;
    if (input.left) moveX -= 1;
    if (input.right) moveX += 1;

    const isMoving = moveX !== 0 || moveZ !== 0;

    // Velocidade de deslocamento (Caminhada = 4.5 m/s, Corrida = 8.5 m/s)
    let moveSpeed = 4.8;
    const canRun = stats.energy > 5;
    const isRunning = isMoving && input.sprint && canRun;

    if (isRunning) {
      moveSpeed = 9.0;
    }

    if (isMoving) {
      // Normaliza vetor local
      const len = Math.sqrt(moveX * moveX + moveZ * moveZ);
      const normX = moveX / len;
      const normZ = moveZ / len;

      // Rotaciona pela orientação da câmera (Yaw)
      const cosYaw = Math.cos(cameraYaw);
      const sinYaw = Math.sin(cameraYaw);

      const worldMoveX = normX * cosYaw - normZ * sinYaw;
      const worldMoveZ = normX * sinYaw + normZ * cosYaw;

      // Ângulo alvo de rotação do personagem
      this.targetAngle = Math.atan2(worldMoveX, worldMoveZ);

      // Deslocamento desejado no frame
      const stepX = worldMoveX * moveSpeed * delta;
      const stepZ = worldMoveZ * moveSpeed * delta;

      // 2. Colisão Swept Axis contra edifícios e obstáculos
      const playerRadius = 0.45;
      const nextPosX = this.position.x + stepX;
      const nextPosZ = this.position.z + stepZ;

      // Teste Eixo X
      const testBoxX = new THREE.Box3(
        new THREE.Vector3(nextPosX - playerRadius, this.position.y + 0.1, this.position.z - playerRadius),
        new THREE.Vector3(nextPosX + playerRadius, this.position.y + 1.8, this.position.z + playerRadius)
      );

      let collidesX = false;
      for (const col of colliders) {
        if (testBoxX.intersectsBox(col)) {
          collidesX = true;
          break;
        }
      }
      if (!collidesX) {
        this.position.x = nextPosX;
      }

      // Teste Eixo Z
      const testBoxZ = new THREE.Box3(
        new THREE.Vector3(this.position.x - playerRadius, this.position.y + 0.1, nextPosZ - playerRadius),
        new THREE.Vector3(this.position.x + playerRadius, this.position.y + 1.8, nextPosZ + playerRadius)
      );

      let collidesZ = false;
      for (const col of colliders) {
        if (testBoxZ.intersectsBox(col)) {
          collidesZ = true;
          break;
        }
      }
      if (!collidesZ) {
        this.position.z = nextPosZ;
      }

      // Limites do mundo de Luanda (-160 a 160)
      this.position.x = Math.max(-160, Math.min(160, this.position.x));
      this.position.z = Math.max(-160, Math.min(160, this.position.z));
    }

    // 3. Salto e Física Vertical (Gravidade)
    if (input.jump && this.isGrounded) {
      this.jumpVelocity = 8.5;
      this.isGrounded = false;
      this.animState = 'jump';
      soundFx.playJump();
    }

    if (!this.isGrounded) {
      this.jumpVelocity += this.gravity * delta;
      this.position.y += this.jumpVelocity * delta;

      // Nível do chão (piso base Y = 0)
      if (this.position.y <= 0) {
        this.position.y = 0;
        this.jumpVelocity = 0;
        this.isGrounded = true;
        soundFx.playLand();
      }
    }

    // 4. Rotação Suave do Personagem (Slerp / Angular lerp)
    let diff = this.targetAngle - this.rotationY;
    while (diff < -Math.PI) diff += Math.PI * 2;
    while (diff > Math.PI) diff -= Math.PI * 2;
    this.rotationY += diff * Math.min(1, 14 * delta);

    // 5. Atualização da Posição do Grupo 3D
    this.mesh.position.copy(this.position);
    this.mesh.rotation.y = this.rotationY;

    // 6. Animações Procedurais (IK / Ciclo de Movimento)
    this.updateAnimations(delta, isMoving, isRunning);

    // 7. Sons de Passos
    if (isMoving && this.isGrounded) {
      this.footstepTimer += delta * (isRunning ? 12 : 7.5);
      if (this.footstepTimer >= Math.PI) {
        this.footstepTimer = 0;
        soundFx.playFootstep(isRunning);
      }
    } else {
      this.footstepTimer = 0;
    }
  }

  private updateAnimations(delta: number, isMoving: boolean, isRunning: boolean) {
    if (!this.isGrounded) {
      // Estado de Salto: pernas fletidas, braços erguidos
      this.animState = 'jump';
      this.leftLegGroup.rotation.x = -0.4;
      this.rightLegGroup.rotation.x = -0.6;
      this.leftArmGroup.rotation.x = 0.8;
      this.rightArmGroup.rotation.x = 0.8;
      this.torsoGroup.position.y = 0.95;
      return;
    }

    if (isMoving) {
      this.animState = isRunning ? 'run' : 'walk';
      const animFreq = isRunning ? 14 : 8;
      this.animTimer += delta * animFreq;

      const swing = Math.sin(this.animTimer);
      const amp = isRunning ? 0.85 : 0.55;

      // Pernas em oposição
      this.leftLegGroup.rotation.x = swing * amp;
      this.rightLegGroup.rotation.x = -swing * amp;

      // Braços em oposição às pernas
      this.leftArmGroup.rotation.x = -swing * (amp * 0.9);
      this.rightArmGroup.rotation.x = swing * (amp * 0.9);

      // Inclinação do tronco em corrida para frente
      this.torsoGroup.rotation.x = isRunning ? 0.18 : 0.05;

      // Balanço vertical suave dos passos
      this.torsoGroup.position.y = 0.95 + Math.abs(Math.cos(this.animTimer)) * (isRunning ? 0.08 : 0.04);
    } else {
      // Estado Idle (Parado / Respiração suave)
      this.animState = 'idle';
      this.animTimer += delta * 2.2;

      const breath = Math.sin(this.animTimer) * 0.025;
      this.torsoGroup.position.y = 0.95 + breath;
      this.torsoGroup.rotation.x = 0;

      // Reset suave de membros
      this.leftLegGroup.rotation.x *= 0.85;
      this.rightLegGroup.rotation.x *= 0.85;
      this.leftArmGroup.rotation.x *= 0.85;
      this.rightArmGroup.rotation.x *= 0.85;
    }
  }
}
