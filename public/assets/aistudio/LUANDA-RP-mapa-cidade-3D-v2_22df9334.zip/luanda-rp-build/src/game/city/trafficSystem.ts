/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

export interface TrafficCar {
  mesh: THREE.Group;
  wheels: THREE.Mesh[];
  axis: 'x' | 'z';
  minCoord: number;
  maxCoord: number;
  fixedCoord: number;
  direction: 1 | -1;
  speed: number;
  headlights: THREE.Mesh[];
}

export interface DrivableVehicle {
  mesh: THREE.Group;
  wheels: THREE.Mesh[];
  position: THREE.Vector3;
  velocity: number;
  steering: number;
  rotationY: number;
  maxSpeed: number;
  acceleration: number;
  headlights: THREE.Mesh[];
}

// Constrói um carro citadino estilizado de Luanda
export function createSedanCar(colorHex: number, plateText: string): { mesh: THREE.Group; wheels: THREE.Mesh[]; headlights: THREE.Mesh[] } {
  const car = new THREE.Group();
  const wheels: THREE.Mesh[] = [];
  const headlights: THREE.Mesh[] = [];

  const bodyMat = new THREE.MeshStandardMaterial({ color: colorHex, roughness: 0.35, metalness: 0.5 });
  const glassMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1, metalness: 0.9, transparent: true, opacity: 0.8 });
  const blackMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.8 });
  const lightMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xfef08a, emissiveIntensity: 0.6 });
  const redLightMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, emissive: 0xdc2626, emissiveIntensity: 0.5 });

  // Chassi inferior
  const chassisGeo = new THREE.BoxGeometry(1.8, 0.65, 3.8);
  const chassis = new THREE.Mesh(chassisGeo, bodyMat);
  chassis.position.y = 0.65;
  chassis.castShadow = true;
  car.add(chassis);

  // Cabine superior com teto e vidros
  const cabinGeo = new THREE.BoxGeometry(1.5, 0.65, 2.0);
  const cabin = new THREE.Mesh(cabinGeo, bodyMat);
  cabin.position.set(0, 1.25, -0.2);
  cabin.castShadow = true;
  car.add(cabin);

  // Pára-brisas
  const winFGeo = new THREE.PlaneGeometry(1.4, 0.55);
  const winF = new THREE.Mesh(winFGeo, glassMat);
  winF.position.set(0, 1.25, 0.82);
  car.add(winF);

  // Pára-brisas traseiro
  const winR = new THREE.Mesh(winFGeo, glassMat);
  winR.position.set(0, 1.25, -1.22);
  winR.rotateY(Math.PI);
  car.add(winR);

  // 4 Rodas
  const wheelPositions: [number, number, number][] = [
    [-0.9, 0.35, 1.1],
    [0.9, 0.35, 1.1],
    [-0.9, 0.35, -1.1],
    [0.9, 0.35, -1.1],
  ];

  wheelPositions.forEach(([wx, wy, wz]) => {
    const tireGeo = new THREE.CylinderGeometry(0.35, 0.35, 0.25, 14);
    tireGeo.rotateZ(Math.PI / 2);
    const tire = new THREE.Mesh(tireGeo, blackMat);
    tire.position.set(wx, wy, wz);
    tire.castShadow = true;
    car.add(tire);
    wheels.push(tire);
  });

  // Faróis dianteiros
  const hlGeo = new THREE.BoxGeometry(0.3, 0.16, 0.08);
  const hlL = new THREE.Mesh(hlGeo, lightMat);
  hlL.position.set(-0.6, 0.7, 1.92);
  car.add(hlL);
  headlights.push(hlL);

  const hlR = new THREE.Mesh(hlGeo, lightMat);
  hlR.position.set(0.6, 0.7, 1.92);
  car.add(hlR);
  headlights.push(hlR);

  // Faróis traseiros
  const tlL = new THREE.Mesh(hlGeo, redLightMat);
  tlL.position.set(-0.6, 0.7, -1.92);
  car.add(tlL);

  const tlR = new THREE.Mesh(hlGeo, redLightMat);
  tlR.position.set(0.6, 0.7, -1.92);
  car.add(tlR);

  return { mesh: car, wheels, headlights };
}

// Cria os carros de tráfego que circulam automaticamente em Luanda
export function setupLuandaTraffic(rootGroup: THREE.Group): TrafficCar[] {
  const traffic: TrafficCar[] = [];

  // 1. Candongueiro em movimento na Marginal Norte-Sul (Avenida 4 de Fevereiro)
  const van1 = createSedanCar(0x1d4ed8, 'LD-88-21-RP');
  // Pinta o teto de branco como candongueiro clássico
  const roofGeo = new THREE.BoxGeometry(1.52, 0.15, 2.05);
  const roof = new THREE.Mesh(roofGeo, new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 }));
  roof.position.set(0, 1.6, -0.2);
  van1.mesh.add(roof);

  van1.mesh.position.set(-9, 0, -60);
  rootGroup.add(van1.mesh);

  traffic.push({
    mesh: van1.mesh,
    wheels: van1.wheels,
    axis: 'z',
    minCoord: -130,
    maxCoord: 130,
    fixedCoord: -9,
    direction: 1,
    speed: 12.0,
    headlights: van1.headlights,
  });

  // 2. Táxi Amarelo em movimento na Marginal Sul-Norte
  const taxi = createSedanCar(0xfacc15, 'LD-44-12-TX');
  taxi.mesh.position.set(-5, 0, 80);
  taxi.mesh.rotation.y = Math.PI;
  rootGroup.add(taxi.mesh);

  traffic.push({
    mesh: taxi.mesh,
    wheels: taxi.wheels,
    axis: 'z',
    minCoord: -130,
    maxCoord: 130,
    fixedCoord: -5,
    direction: -1,
    speed: 11.0,
    headlights: taxi.headlights,
  });

  // 3. Viatura Executiva preta na Avenida Central Leste-Oeste (Rumo à Maianga / Viana)
  const carEast = createSedanCar(0x1e293b, 'LD-99-01-GOV');
  carEast.mesh.position.set(30, 0, -2);
  carEast.mesh.rotation.y = Math.PI / 2;
  rootGroup.add(carEast.mesh);

  traffic.push({
    mesh: carEast.mesh,
    wheels: carEast.wheels,
    axis: 'x',
    minCoord: 20,
    maxCoord: 150,
    fixedCoord: -2,
    direction: 1,
    speed: 13.5,
    headlights: carEast.headlights,
  });

  // 4. Pickup Vermelha na Avenida Central Oeste-Leste
  const carWest = createSedanCar(0xdc2626, 'LD-33-88-RP');
  carWest.mesh.position.set(130, 0, 2);
  carWest.mesh.rotation.y = -Math.PI / 2;
  rootGroup.add(carWest.mesh);

  traffic.push({
    mesh: carWest.mesh,
    wheels: carWest.wheels,
    axis: 'x',
    minCoord: 20,
    maxCoord: 150,
    fixedCoord: 2,
    direction: -1,
    speed: 10.5,
    headlights: carWest.headlights,
  });

  // 5. Candongueiro na Avenida Talatona
  const vanTalatona = createSedanCar(0x1d4ed8, 'LD-12-55-TL');
  const roof2 = new THREE.Mesh(roofGeo, new THREE.MeshStandardMaterial({ color: 0xffffff }));
  roof2.position.set(0, 1.6, -0.2);
  vanTalatona.mesh.add(roof2);
  vanTalatona.mesh.position.set(82, 0, 30);
  rootGroup.add(vanTalatona.mesh);

  traffic.push({
    mesh: vanTalatona.mesh,
    wheels: vanTalatona.wheels,
    axis: 'z',
    minCoord: 20,
    maxCoord: 140,
    fixedCoord: 82,
    direction: 1,
    speed: 11.5,
    headlights: vanTalatona.headlights,
  });

  return traffic;
}
