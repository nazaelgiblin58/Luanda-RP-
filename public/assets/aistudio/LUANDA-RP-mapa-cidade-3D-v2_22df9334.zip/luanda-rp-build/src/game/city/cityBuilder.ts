/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { District, InteractableObject } from '../types';
import { TrafficCar, DrivableVehicle, setupLuandaTraffic, createSedanCar } from './trafficSystem';

export interface CityData {
  rootGroup: THREE.Group;
  colliders: THREE.Box3[];
  interactables: InteractableObject[];
  districts: District[];
  streetLamps: THREE.PointLight[];
  oceanMesh?: THREE.Mesh;
  flagMesh?: THREE.Mesh;
  swayingTrees: THREE.Group[];
  trafficVehicles: TrafficCar[];
  drivableVan: DrivableVehicle;
}

// Procedural texture generators
function createRoadTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Asfalto escuro
  ctx.fillStyle = '#22252a';
  ctx.fillRect(0, 0, 512, 512);

  // Textura granular de asfalto
  for (let i = 0; i < 4000; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const brightness = 30 + Math.random() * 25;
    ctx.fillStyle = `rgb(${brightness},${brightness},${brightness})`;
    ctx.fillRect(x, y, 2, 2);
  }

  // Linhas brancas de borda
  ctx.fillStyle = '#e5e7eb';
  ctx.fillRect(24, 0, 12, 512);
  ctx.fillRect(476, 0, 12, 512);

  // Linhas tracejadas amarelas centrais
  ctx.fillStyle = '#fbbf24';
  for (let y = 0; y < 512; y += 64) {
    ctx.fillRect(250, y + 10, 12, 44);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function createCalcadaTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  // Base calçada bege clara
  ctx.fillStyle = '#dcd5c7';
  ctx.fillRect(0, 0, 256, 256);

  // Padrão de ondas da Calçada Portuguesa (típico da Marginal de Luanda)
  ctx.strokeStyle = '#2d3139';
  ctx.lineWidth = 14;
  ctx.lineCap = 'round';

  for (let y = 0; y <= 256; y += 64) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(64, y - 30, 128, y + 30, 192, y - 30);
    ctx.bezierCurveTo(224, y, 256, y, 256, y);
    ctx.stroke();
  }

  // Textura de pedras
  for (let i = 0; i < 2000; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    ctx.fillStyle = Math.random() > 0.5 ? '#b8b09f' : '#efede6';
    ctx.fillRect(x, y, 2, 2);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function createBuildingWindowTexture(colorTheme: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = colorTheme;
  ctx.fillRect(0, 0, 256, 256);

  const cols = 4;
  const rows = 8;
  const w = 40;
  const h = 20;
  const gapX = (256 - cols * w) / (cols + 1);
  const gapY = (256 - rows * h) / (rows + 1);

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const x = gapX + c * (w + gapX);
      const y = gapY + r * (h + gapY);

      // Vidro azulado reflexivo com variação de luz interna
      const isLit = Math.random() > 0.4;
      ctx.fillStyle = isLit ? '#fef08a' : '#1e3a5f';
      ctx.fillRect(x, y, w, h);

      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, w, h);
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function createAngolaFlagTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 300;
  canvas.height = 200;
  const ctx = canvas.getContext('2d')!;

  // Metade Superior Vermelha
  ctx.fillStyle = '#dc2626';
  ctx.fillRect(0, 0, 300, 100);

  // Metade Inferior Preta
  ctx.fillStyle = '#111827';
  ctx.fillRect(0, 100, 300, 100);

  // Emblema Central em Amarelo (Estrela + Meia Roda Dentada + Catana)
  ctx.fillStyle = '#facc15';
  ctx.strokeStyle = '#facc15';
  ctx.lineWidth = 8;

  // Meio arco de engrenagem
  ctx.beginPath();
  ctx.arc(150, 100, 36, Math.PI * 0.4, Math.PI * 1.5, false);
  ctx.stroke();

  // Catana estilizada diagonal
  ctx.beginPath();
  ctx.moveTo(130, 130);
  ctx.lineTo(170, 70);
  ctx.lineWidth = 10;
  ctx.stroke();

  // Estrela dourada de 5 pontas
  const cx = 155;
  const cy = 95;
  const spikes = 5;
  const outerR = 12;
  const innerR = 6;
  ctx.beginPath();
  let rot = (Math.PI / 2) * 3;
  const step = Math.PI / spikes;
  ctx.moveTo(cx, cy - outerR);
  for (let i = 0; i < spikes; i++) {
    let x = cx + Math.cos(rot) * outerR;
    let y = cy + Math.sin(rot) * outerR;
    ctx.lineTo(x, y);
    rot += step;
    x = cx + Math.cos(rot) * innerR;
    y = cy + Math.sin(rot) * innerR;
    ctx.lineTo(x, y);
    rot += step;
  }
  ctx.closePath();
  ctx.fill();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function buildLuandaCity(): CityData {
  const root = new THREE.Group();
  root.name = 'LuandaCity';
  const colliders: THREE.Box3[] = [];
  const interactables: InteractableObject[] = [];
  const streetLamps: THREE.PointLight[] = [];
  const swayingTrees: THREE.Group[] = [];

  const roadTex = createRoadTexture();
  roadTex.repeat.set(1, 16);

  const calcadaTex = createCalcadaTexture();
  calcadaTex.repeat.set(8, 8);

  const flagTex = createAngolaFlagTexture();

  // 1. TERRENO BASE & ZONAS (LUANDA)
  // Ilha ao Oeste (Z negativo ou X negativo), Oceano Atlântico, Baixa no centro
  const groundGeo = new THREE.PlaneGeometry(360, 360, 32, 32);
  groundGeo.rotateX(-Math.PI / 2);

  // Material de terreno misto (terra avermelhada de Luanda + vegetação rala urbana)
  const groundMat = new THREE.MeshStandardMaterial({
    color: 0x9a5b3a, // Terra vermelha típica de Luanda
    roughness: 0.9,
    metalness: 0.05,
  });
  const groundMesh = new THREE.Mesh(groundGeo, groundMat);
  groundMesh.receiveShadow = true;
  root.add(groundMesh);

  // Oceano Atlântico (Ilha de Luanda no lado Oeste: X de -80 a -180)
  const oceanGeo = new THREE.PlaneGeometry(160, 360, 32, 32);
  oceanGeo.rotateX(-Math.PI / 2);
  const oceanMat = new THREE.MeshStandardMaterial({
    color: 0x0284c7, // Azul atlântico
    roughness: 0.15,
    metalness: 0.6,
    transparent: true,
    opacity: 0.88,
  });
  const oceanMesh = new THREE.Mesh(oceanGeo, oceanMat);
  oceanMesh.position.set(-130, -0.4, 0);
  root.add(oceanMesh);

  // Praia da Ilha (Faixa de Areia Dourada)
  const beachGeo = new THREE.PlaneGeometry(24, 340);
  beachGeo.rotateX(-Math.PI / 2);
  const beachMat = new THREE.MeshStandardMaterial({
    color: 0xe5c890,
    roughness: 0.95,
  });
  const beachMesh = new THREE.Mesh(beachGeo, beachMat);
  beachMesh.position.set(-42, -0.05, 0);
  root.add(beachMesh);

  // Calçadão da Marginal de Luanda
  const calçadaGeo = new THREE.PlaneGeometry(16, 320);
  calçadaGeo.rotateX(-Math.PI / 2);
  const calçadaMat = new THREE.MeshStandardMaterial({
    map: calcadaTex,
    roughness: 0.6,
  });
  const calçadaMesh = new THREE.Mesh(calçadaGeo, calçadaMat);
  calçadaMesh.position.set(-24, 0.02, 0);
  calçadaMesh.receiveShadow = true;
  root.add(calçadaMesh);

  // 2. REDE DE ESTRADAS & AVENIDAS (Avenida 4 de Fevereiro / Deolinda Rodrigues / Revolução)
  // Avenida Principal Norte-Sul (Avenida 4 de Fevereiro / Marginal)
  const roadMat = new THREE.MeshStandardMaterial({
    map: roadTex,
    roughness: 0.7,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });

  const mainRoadGeo = new THREE.PlaneGeometry(18, 320);
  mainRoadGeo.rotateX(-Math.PI / 2);
  const mainRoad = new THREE.Mesh(mainRoadGeo, roadMat);
  mainRoad.position.set(-7, 0.05, 0);
  mainRoad.receiveShadow = true;
  root.add(mainRoad);

  // Avenida Leste-Oeste Central (Rumo a Maianga e Viana)
  const eastRoadGeo = new THREE.PlaneGeometry(180, 18);
  eastRoadGeo.rotateX(-Math.PI / 2);
  const eastRoadTex = roadTex.clone();
  eastRoadTex.repeat.set(10, 1);
  const eastRoadMat = new THREE.MeshStandardMaterial({
    map: eastRoadTex,
    roughness: 0.7,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const eastRoad = new THREE.Mesh(eastRoadGeo, eastRoadMat);
  eastRoad.position.set(80, 0.05, 0);
  eastRoad.receiveShadow = true;
  root.add(eastRoad);

  // Avenida Sul (Talatona / Kilamba)
  const southRoadGeo = new THREE.PlaneGeometry(18, 140);
  southRoadGeo.rotateX(-Math.PI / 2);
  const southRoad = new THREE.Mesh(southRoadGeo, roadMat);
  southRoad.position.set(80, 0.05, 75);
  southRoad.receiveShadow = true;
  root.add(southRoad);

  // Avenida Norte (Cacuaco)
  const northRoadGeo = new THREE.PlaneGeometry(18, 140);
  northRoadGeo.rotateX(-Math.PI / 2);
  const northRoad = new THREE.Mesh(northRoadGeo, roadMat);
  northRoad.position.set(80, 0.05, -75);
  northRoad.receiveShadow = true;
  root.add(northRoad);

  // Rotunda Central de Luanda (Largo da Mutamba / 1º de Maio)
  const rotundaRadius = 16;
  const rotundaGeo = new THREE.CylinderGeometry(rotundaRadius, rotundaRadius, 0.35, 32);
  const rotundaMat = new THREE.MeshStandardMaterial({
    color: 0x15803d, // Gramado verde
    roughness: 0.8,
  });
  const rotundaMesh = new THREE.Mesh(rotundaGeo, rotundaMat);
  rotundaMesh.position.set(80, 0.17, 0);
  root.add(rotundaMesh);

  // Obelisco Central & Monumento da Independência com Bandeira Nacional 🇦🇴
  const obeliscoBaseGeo = new THREE.BoxGeometry(4, 1.2, 4);
  const obeliscoBaseMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4 });
  const obeliscoBase = new THREE.Mesh(obeliscoBaseGeo, obeliscoBaseMat);
  obeliscoBase.position.set(80, 0.9, 0);
  root.add(obeliscoBase);

  const obeliscoTowerGeo = new THREE.CylinderGeometry(0.8, 1.8, 14, 8);
  const obeliscoTowerMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    metalness: 0.2,
    roughness: 0.3,
  });
  const obeliscoTower = new THREE.Mesh(obeliscoTowerGeo, obeliscoTowerMat);
  obeliscoTower.position.set(80, 8, 0);
  root.add(obeliscoTower);

  // Mastro da Bandeira de Angola
  const poleGeo = new THREE.CylinderGeometry(0.08, 0.08, 10, 16);
  const poleMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8, roughness: 0.2 });
  const flagPole = new THREE.Mesh(poleGeo, poleMat);
  flagPole.position.set(80, 16, 0);
  root.add(flagPole);

  const flagGeo = new THREE.PlaneGeometry(4.5, 3, 10, 6);
  const flagMat = new THREE.MeshStandardMaterial({
    map: flagTex,
    side: THREE.DoubleSide,
    roughness: 0.5,
  });
  const flagMesh = new THREE.Mesh(flagGeo, flagMat);
  flagMesh.position.set(82.3, 19.5, 0);
  root.add(flagMesh);

  interactables.push({
    id: 'monumento-independencia',
    type: 'monument',
    title: 'Monumento da Independência 🇦🇴',
    subtitle: 'Largo Central da República de Angola',
    prompt: '[E] Reverenciar História Nacional',
    position: [80, 0.5, 3],
    radius: 4,
    district: 'centro',
    data: { quote: 'A paz e o progresso do povo angolano!' },
  });

  // 3. EDIFÍCIOS HISTÓRICOS & MODERNOS DE LUANDA
  // Helper para construir edifícios compostos com colisor e detalhes
  const buildComplex = (
    name: string,
    x: number,
    z: number,
    w: number,
    h: number,
    d: number,
    themeColor: string,
    roofColor: number,
    label?: string,
    accentColor: number = 0x1e293b
  ) => {
    const group = new THREE.Group();
    group.name = name;

    const winTex = createBuildingWindowTexture(themeColor);
    winTex.repeat.set(Math.max(1, Math.round(w / 8)), Math.max(1, Math.round(h / 6)));

    // Corpo Principal
    const bodyGeo = new THREE.BoxGeometry(w, h, d);
    const bodyMat = new THREE.MeshStandardMaterial({
      map: winTex,
      roughness: 0.4,
      metalness: 0.15,
    });
    const bodyMesh = new THREE.Mesh(bodyGeo, bodyMat);
    bodyMesh.position.y = h / 2;
    bodyMesh.castShadow = true;
    bodyMesh.receiveShadow = true;
    group.add(bodyMesh);

    // Teto / Cobertura
    const roofGeo = new THREE.BoxGeometry(w + 0.8, 1.2, d + 0.8);
    const roofMat = new THREE.MeshStandardMaterial({ color: roofColor, roughness: 0.7 });
    const roofMesh = new THREE.Mesh(roofGeo, roofMat);
    roofMesh.position.y = h + 0.6;
    roofMesh.castShadow = true;
    group.add(roofMesh);

    // Entrada / Porta de vidro com marquise
    const entranceGeo = new THREE.BoxGeometry(4, 3, 1.2);
    const entranceMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.1,
      metalness: 0.9,
    });
    const entranceMesh = new THREE.Mesh(entranceGeo, entranceMat);
    entranceMesh.position.set(0, 1.5, d / 2 + 0.5);
    group.add(entranceMesh);

    // Marquise
    const canopyGeo = new THREE.BoxGeometry(5.5, 0.3, 3);
    const canopyMat = new THREE.MeshStandardMaterial({ color: accentColor, roughness: 0.3 });
    const canopyMesh = new THREE.Mesh(canopyGeo, canopyMat);
    canopyMesh.position.set(0, 3.1, d / 2 + 1.4);
    group.add(canopyMesh);

    // Placa com letreiro
    if (label) {
      const labelCanvas = document.createElement('canvas');
      labelCanvas.width = 512;
      labelCanvas.height = 128;
      const lctx = labelCanvas.getContext('2d')!;
      lctx.fillStyle = '#0f172a';
      lctx.fillRect(0, 0, 512, 128);
      lctx.strokeStyle = '#f59e0b';
      lctx.lineWidth = 6;
      lctx.strokeRect(4, 4, 504, 120);

      lctx.fillStyle = '#ffffff';
      lctx.font = 'bold 36px sans-serif';
      lctx.textAlign = 'center';
      lctx.textBaseline = 'middle';
      lctx.fillText(label, 256, 64);

      const labelTex = new THREE.CanvasTexture(labelCanvas);
      labelTex.colorSpace = THREE.SRGBColorSpace;
      const labelGeo = new THREE.PlaneGeometry(4.8, 1.2);
      const labelMat = new THREE.MeshStandardMaterial({ map: labelTex, roughness: 0.2 });
      const labelMesh = new THREE.Mesh(labelGeo, labelMat);
      labelMesh.position.set(0, 4.2, d / 2 + 0.65);
      group.add(labelMesh);
    }

    group.position.set(x, 0, z);
    root.add(group);

    // Adiciona colisor Box3
    const box = new THREE.Box3().setFromObject(group);
    colliders.push(box);

    return group;
  };

  // BANCO BFA & MULTICAIXA (Centro / Baixa)
  buildComplex('BancoBFA', 26, -30, 22, 26, 18, '#1e3a8a', 0xd97706, 'BANCO BFA — MULTICAIXA', 0xd97706);
  interactables.push({
    id: 'atm-bfa-centro',
    type: 'atm',
    title: 'Multicaixa BFA / BAI 💳',
    subtitle: 'Terminal Bancário Automático de Luanda',
    prompt: '[E] Acessar Multicaixa (Saldo / Levantamento)',
    position: [26, 0.5, -20],
    radius: 3.5,
    district: 'centro',
    data: { bankName: 'Banco de Fomento Angola (BFA)' },
  });

  // ESQUADRA DA POLÍCIA NACIONAL (Maianga / Centro)
  buildComplex('PoliciaNacional', 26, 30, 24, 18, 20, '#1e293b', 0x1d4ed8, 'POLÍCIA NACIONAL — LUANDA', 0x2563eb);
  interactables.push({
    id: 'esquadra-policia',
    type: 'police',
    title: 'Esquadra da Polícia Nacional 🚓',
    subtitle: 'Comando Provincial de Luanda',
    prompt: '[E] Falar com o Oficial de Dia',
    position: [26, 0.5, 20],
    radius: 3.5,
    district: 'maianga',
    data: { officer: 'Comandante Silva' },
  });

  // HOSPITAL MUNICIPAL JOSINA MACHEL (Maianga)
  buildComplex('HospitalGeral', 48, 65, 30, 22, 22, '#f8fafc', 0xef4444, 'HOSPITAL JOSINA MACHEL 🏥', 0xdc2626);
  interactables.push({
    id: 'hospital-maianga',
    type: 'hospital',
    title: 'Hospital Josina Machel 🏥',
    subtitle: 'Urgências e Cuidados Médicos',
    prompt: '[E] Fazer Consulta e Curar Saúde',
    position: [48, 0.5, 54],
    radius: 3.5,
    district: 'maianga',
  });

  // TORRE SONANGOL (Edifício Alto da Baixa de Luanda)
  buildComplex('TorreSonangol', 50, -32, 24, 48, 24, '#0f172a', 0xf59e0b, 'TORRE SONANGOL ⚡', 0xf59e0b);

  // POSTO DE COMBUSTÍVEL SONANGOL (Talatona)
  const buildGasStation = (x: number, z: number) => {
    const stationGroup = new THREE.Group();
    // Cobertura Sonangol laranja e amarela
    const canopyGeo = new THREE.BoxGeometry(22, 1.2, 16);
    const canopyMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.3 });
    const canopy = new THREE.Mesh(canopyGeo, canopyMat);
    canopy.position.set(0, 6.5, 0);
    canopy.castShadow = true;
    stationGroup.add(canopy);

    // Pilares
    for (const px of [-7, 7]) {
      for (const pz of [-5, 5]) {
        const pillarGeo = new THREE.CylinderGeometry(0.4, 0.4, 6.5, 16);
        const pillarMat = new THREE.MeshStandardMaterial({ color: 0xdc2626 });
        const pillar = new THREE.Mesh(pillarGeo, pillarMat);
        pillar.position.set(px, 3.25, pz);
        stationGroup.add(pillar);
      }
    }

    // Bombas de combustível
    for (const bz of [-2.5, 2.5]) {
      const pumpGeo = new THREE.BoxGeometry(1.6, 2.2, 1.2);
      const pumpMat = new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.3 });
      const pump = new THREE.Mesh(pumpGeo, pumpMat);
      pump.position.set(0, 1.1, bz);
      stationGroup.add(pump);
    }

    // Loja de conveniência
    const shopGeo = new THREE.BoxGeometry(14, 4.5, 10);
    const shopMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.5 });
    const shop = new THREE.Mesh(shopGeo, shopMat);
    shop.position.set(0, 2.25, -16);
    shop.castShadow = true;
    stationGroup.add(shop);

    stationGroup.position.set(x, 0, z);
    root.add(stationGroup);

    colliders.push(new THREE.Box3().setFromObject(shop));
  };
  buildGasStation(120, 45);
  interactables.push({
    id: 'posto-sonangol',
    type: 'station',
    title: 'Posto Sonangol Talatona ⛽',
    subtitle: 'Gasolina e Conveniência',
    prompt: '[E] Abastecer e Comprar Mantimentos',
    position: [120, 0.5, 45],
    radius: 4,
    district: 'talatona',
  });

  // QUIOSQUES GASTRONÓMICOS DA ILHA DE LUANDA (Mufete, Calulu, Peixe Fresco, Cuca)
  const buildBeachKiosk = (x: number, z: number, name: string, foodName: string) => {
    const kioskGroup = new THREE.Group();

    // Cabana de madeira com palha
    const baseGeo = new THREE.BoxGeometry(6, 3.2, 5);
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.8 });
    const base = new THREE.Mesh(baseGeo, baseMat);
    base.position.y = 1.6;
    kioskGroup.add(base);

    // Balcão aberto
    const counterGeo = new THREE.BoxGeometry(5.2, 1.1, 1.4);
    const counterMat = new THREE.MeshStandardMaterial({ color: 0xfef3c7, roughness: 0.5 });
    const counter = new THREE.Mesh(counterGeo, counterMat);
    counter.position.set(0, 1.1, 2.6);
    kioskGroup.add(counter);

    // Telhado de palha/tenda
    const roofGeo = new THREE.ConeGeometry(5.2, 2.2, 4);
    roofGeo.rotateY(Math.PI / 4);
    const roofMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.9 });
    const roof = new THREE.Mesh(roofGeo, roofMat);
    roof.position.y = 4.2;
    kioskGroup.add(roof);

    // Mesas de esplanada com cadeiras
    for (const offset of [-4.5, 4.5]) {
      const tableGeo = new THREE.CylinderGeometry(1.2, 1.2, 1, 16);
      const tableMat = new THREE.MeshStandardMaterial({ color: 0xffffff });
      const table = new THREE.Mesh(tableGeo, tableMat);
      table.position.set(offset, 0.5, 3);
      kioskGroup.add(table);

      // Guarda-sol colorido
      const umbrellaGeo = new THREE.ConeGeometry(2, 0.8, 8);
      const umbrellaMat = new THREE.MeshStandardMaterial({ color: 0xef4444 });
      const umbrella = new THREE.Mesh(umbrellaGeo, umbrellaMat);
      umbrella.position.set(offset, 2.5, 3);
      kioskGroup.add(umbrella);
    }

    kioskGroup.position.set(x, 0, z);
    root.add(kioskGroup);

    colliders.push(new THREE.Box3().setFromObject(base));

    interactables.push({
      id: `kiosk-${name.toLowerCase().replace(/\s+/g, '-')}`,
      type: 'food',
      title: `${name} 🐟🍲`,
      subtitle: `Especialidade: ${foodName} & Cuca Gelada`,
      prompt: '[E] Comer Gastronomia Angolana',
      position: [x, 0.5, z + 2],
      radius: 3.5,
      district: 'ilha',
      data: { food: foodName },
    });
  };

  buildBeachKiosk(-32, -45, 'Kioske Ilha Dourada', 'Mufete de Peixe com Feijão de Óleo de Palma');
  buildBeachKiosk(-32, 40, 'Esplanada Mar e Sol', 'Calulu de Peixe Seco & Funge');

  // MERCADO POPULAR DE VIANA / CONGOLENSES (Bancadas de Zungueiras, Toldos coloridos)
  const buildMarketStalls = (centerX: number, centerZ: number) => {
    const marketGroup = new THREE.Group();
    const colors = [0xdc2626, 0x2563eb, 0xfacc15, 0x16a34a, 0x9333ea];

    for (let i = 0; i < 8; i++) {
      const col = i % 4;
      const row = Math.floor(i / 4);
      const sx = (col - 1.5) * 5.5;
      const sz = (row - 0.5) * 6;

      const stall = new THREE.Group();
      // Caixote de madeira
      const benchGeo = new THREE.BoxGeometry(3.5, 1, 2);
      const benchMat = new THREE.MeshStandardMaterial({ color: 0x854d0e, roughness: 0.8 });
      const bench = new THREE.Mesh(benchGeo, benchMat);
      bench.position.y = 0.5;
      stall.add(bench);

      // Frutas / Panos sobre o balcão
      const goodsGeo = new THREE.BoxGeometry(3.2, 0.4, 1.8);
      const goodsMat = new THREE.MeshStandardMaterial({ color: colors[i % colors.length] });
      const goods = new THREE.Mesh(goodsGeo, goodsMat);
      goods.position.y = 1.1;
      stall.add(goods);

      // Toldo de tecido colorido
      const tarpGeo = new THREE.BoxGeometry(4, 0.2, 2.8);
      const tarpMat = new THREE.MeshStandardMaterial({ color: colors[(i + 1) % colors.length], roughness: 0.6 });
      const tarp = new THREE.Mesh(tarpGeo, tarpMat);
      tarp.position.set(0, 2.4, 0);
      stall.add(tarp);

      // Hastes de ferro
      for (const cx of [-1.8, 1.8]) {
        for (const cz of [-1.2, 1.2]) {
          const poleGeo = new THREE.CylinderGeometry(0.04, 0.04, 2.4, 8);
          const poleMat = new THREE.MeshStandardMaterial({ color: 0x334155 });
          const pole = new THREE.Mesh(poleGeo, poleMat);
          pole.position.set(cx, 1.2, cz);
          stall.add(pole);
        }
      }

      stall.position.set(sx, 0, sz);
      marketGroup.add(stall);
      colliders.push(new THREE.Box3().setFromObject(stall));
    }

    marketGroup.position.set(centerX, 0, centerZ);
    root.add(marketGroup);

    interactables.push({
      id: 'mercado-viana',
      type: 'market',
      title: 'Mercado de Viana & Congolenses 🛒',
      subtitle: 'Comércio Popular de Luanda — Frutas, Panos e Artesanato',
      prompt: '[E] Comprar Produtos Frescos',
      position: [centerX, 0.5, centerZ],
      radius: 6,
      district: 'viana',
    });
  };
  buildMarketStalls(135, -45);

  // 4. CANDONGUEIROS AZUL E BRANCO DE LUANDA (Toyota HiAce clássico)
  // Construído em THREE.Group com 10 partes distintas (conforme Three.js Directives)
  const buildCandongueiro = (x: number, z: number, rotY: number, idSuffix: string) => {
    const van = new THREE.Group();
    van.name = `Candongueiro_${idSuffix}`;

    const blueMat = new THREE.MeshStandardMaterial({
      color: 0x1d4ed8, // Azul característico dos candongueiros de Luanda
      roughness: 0.35,
      metalness: 0.4,
    });
    const whiteMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc, // Teto branco característico
      roughness: 0.4,
      metalness: 0.2,
    });
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.1,
      metalness: 0.9,
      transparent: true,
      opacity: 0.8,
    });
    const blackMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.9 });
    const chromeMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8, roughness: 0.2 });
    const lightMat = new THREE.MeshStandardMaterial({
      color: 0xfef08a,
      emissive: 0xfef08a,
      emissiveIntensity: 0.4,
    });
    const redLightMat = new THREE.MeshStandardMaterial({
      color: 0xdc2626,
      emissive: 0xdc2626,
      emissiveIntensity: 0.4,
    });

    const wheels: THREE.Mesh[] = [];
    const headlights: THREE.Mesh[] = [];

    // 1. Chassi inferior azul (Primary silhouette)
    const lowerBodyGeo = new THREE.BoxGeometry(2.1, 1.1, 4.4);
    const lowerBody = new THREE.Mesh(lowerBodyGeo, blueMat);
    lowerBody.position.y = 0.9;
    lowerBody.castShadow = true;
    van.add(lowerBody);

    // 2. Cabine superior com janelas e teto branco (Secondary read)
    const upperBodyGeo = new THREE.BoxGeometry(2.0, 1.0, 4.2);
    const upperBody = new THREE.Mesh(upperBodyGeo, whiteMat);
    upperBody.position.y = 1.95;
    upperBody.castShadow = true;
    van.add(upperBody);

    // 3. Vidro pára-brisas dianteiro
    const frontWindshieldGeo = new THREE.PlaneGeometry(1.8, 0.8);
    const frontWindshield = new THREE.Mesh(frontWindshieldGeo, glassMat);
    frontWindshield.position.set(0, 1.95, 2.12);
    van.add(frontWindshield);

    // 4. Vidros laterais
    const sideWindowGeo = new THREE.PlaneGeometry(3.6, 0.7);
    const sideWindowL = new THREE.Mesh(sideWindowGeo, glassMat);
    sideWindowL.position.set(-1.02, 1.95, -0.2);
    sideWindowL.rotateY(-Math.PI / 2);
    van.add(sideWindowL);

    const sideWindowR = new THREE.Mesh(sideWindowGeo, glassMat);
    sideWindowR.position.set(1.02, 1.95, -0.2);
    sideWindowR.rotateY(Math.PI / 2);
    van.add(sideWindowR);

    // 5. Quatro Rodas com pneus pretos e jantes prateadas
    const wheelPositions: [number, number, number][] = [
      [-1.0, 0.45, 1.4],
      [1.0, 0.45, 1.4],
      [-1.0, 0.45, -1.4],
      [1.0, 0.45, -1.4],
    ];

    wheelPositions.forEach(([wx, wy, wz]) => {
      const tireGeo = new THREE.CylinderGeometry(0.42, 0.42, 0.32, 18);
      tireGeo.rotateZ(Math.PI / 2);
      const tire = new THREE.Mesh(tireGeo, blackMat);
      tire.position.set(wx, wy, wz);
      tire.castShadow = true;
      van.add(tire);
      wheels.push(tire);

      const hubcapGeo = new THREE.CylinderGeometry(0.24, 0.24, 0.34, 12);
      hubcapGeo.rotateZ(Math.PI / 2);
      const hubcap = new THREE.Mesh(hubcapGeo, chromeMat);
      hubcap.position.set(wx, wy, wz);
      van.add(hubcap);
    });

    // 6. Faróis dianteiros amarelos
    const headlightGeo = new THREE.BoxGeometry(0.35, 0.22, 0.1);
    const hlLeft = new THREE.Mesh(headlightGeo, lightMat);
    hlLeft.position.set(-0.7, 1.0, 2.22);
    van.add(hlLeft);
    headlights.push(hlLeft);

    const hlRight = new THREE.Mesh(headlightGeo, lightMat);
    hlRight.position.set(0.7, 1.0, 2.22);
    van.add(hlRight);
    headlights.push(hlRight);

    // 7. Farolins traseiros vermelhos
    const tailLeft = new THREE.Mesh(headlightGeo, redLightMat);
    tailLeft.position.set(-0.7, 1.0, -2.22);
    van.add(tailLeft);

    const tailRight = new THREE.Mesh(headlightGeo, redLightMat);
    tailRight.position.set(0.7, 1.0, -2.22);
    van.add(tailRight);

    // 8. Pára-choques dianteiro e traseiro
    const bumperGeo = new THREE.BoxGeometry(2.1, 0.25, 0.3);
    const bumperF = new THREE.Mesh(bumperGeo, blackMat);
    bumperF.position.set(0, 0.5, 2.25);
    van.add(bumperF);

    const bumperR = new THREE.Mesh(bumperGeo, blackMat);
    bumperR.position.set(0, 0.5, -2.25);
    van.add(bumperR);

    // 9. Matrícula oficial de Luanda ("LD-24-94-RP")
    const plateCanvas = document.createElement('canvas');
    plateCanvas.width = 128;
    plateCanvas.height = 36;
    const pctx = plateCanvas.getContext('2d')!;
    pctx.fillStyle = '#ffffff';
    pctx.fillRect(0, 0, 128, 36);
    pctx.strokeStyle = '#000000';
    pctx.lineWidth = 3;
    pctx.strokeRect(2, 2, 124, 32);
    pctx.fillStyle = '#000000';
    pctx.font = 'bold 16px monospace';
    pctx.textAlign = 'center';
    pctx.textBaseline = 'middle';
    pctx.fillText('LD-24-94-RP', 64, 18);

    const plateTex = new THREE.CanvasTexture(plateCanvas);
    plateTex.colorSpace = THREE.SRGBColorSpace;
    const plateGeo = new THREE.PlaneGeometry(0.7, 0.2);
    const plateMat = new THREE.MeshStandardMaterial({ map: plateTex, roughness: 0.1 });
    const plateMesh = new THREE.Mesh(plateGeo, plateMat);
    plateMesh.position.set(0, 0.5, 2.41);
    van.add(plateMesh);

    // 10. Letreiro na lateral "ROTA: MUTAMBA / VIANA / KILAMBA"
    const signCanvas = document.createElement('canvas');
    signCanvas.width = 256;
    signCanvas.height = 40;
    const sctx = signCanvas.getContext('2d')!;
    sctx.fillStyle = '#1d4ed8';
    sctx.fillRect(0, 0, 256, 40);
    sctx.fillStyle = '#ffffff';
    sctx.font = 'bold 15px sans-serif';
    sctx.textAlign = 'center';
    sctx.textBaseline = 'middle';
    sctx.fillText('MUTAMBA • VIANA • KILAMBA', 128, 20);

    const signTex = new THREE.CanvasTexture(signCanvas);
    signTex.colorSpace = THREE.SRGBColorSpace;
    const signGeo = new THREE.PlaneGeometry(1.6, 0.25);
    const signMat = new THREE.MeshStandardMaterial({ map: signTex, roughness: 0.3 });
    const signMesh = new THREE.Mesh(signGeo, signMat);
    signMesh.position.set(1.02, 1.4, 0);
    signMesh.rotateY(Math.PI / 2);
    van.add(signMesh);

    van.position.set(x, 0, z);
    van.rotation.y = rotY;
    root.add(van);

    colliders.push(new THREE.Box3().setFromObject(van));

    return { van, wheels, headlights };
  };

  // Candongueiro 1 Conduzível: Paragem da Marginal / Baixa
  const van1Data = buildCandongueiro(-14, 5, 0, 'Baixa');
  const drivableVan: DrivableVehicle = {
    mesh: van1Data.van,
    wheels: van1Data.wheels,
    position: new THREE.Vector3(-14, 0, 5),
    velocity: 0,
    steering: 0,
    rotationY: 0,
    maxSpeed: 24,
    acceleration: 15,
    headlights: van1Data.headlights,
  };

  interactables.push({
    id: 'candongueiro-baixa',
    type: 'candongueiro',
    title: 'Candongueiro Azul e Branco (Conduzível) 🚐',
    subtitle: 'Táxi Coletivo de Luanda • Pressione [E] para Conduzir',
    prompt: '[E] Conduzir Candongueiro / Opções',
    position: [-14, 0.5, 5],
    radius: 4.5,
    district: 'centro',
    data: { fare: 200, route: 'Mutamba ➔ Maianga ➔ Viana', isDrivable: true },
  });

  // Candongueiro 2: Terminal do Mercado de Viana
  buildCandongueiro(125, -25, Math.PI / 3, 'Viana');
  interactables.push({
    id: 'candongueiro-viana',
    type: 'candongueiro',
    title: 'Candongueiro de Viana 🚐',
    subtitle: 'Paragem dos Congolenses • Linha Expresso Kilamba',
    prompt: '[E] Embarcar no Candongueiro / Ouvir Rádio',
    position: [125, 0.5, -25],
    radius: 4,
    district: 'viana',
    data: { fare: 250, route: 'Viana ➔ Talatona ➔ Kilamba' },
  });

  // Candongueiro 3: Ilha de Luanda
  buildCandongueiro(-18, -60, -Math.PI / 2, 'Ilha');
  interactables.push({
    id: 'candongueiro-ilha',
    type: 'candongueiro',
    title: 'Candongueiro da Ilha 🚐',
    subtitle: 'Praia da Ilha do Cabo • Rota Turística Marginal',
    prompt: '[E] Entrar no Candongueiro',
    position: [-18, 0.5, -60],
    radius: 4,
    district: 'ilha',
    data: { fare: 300, route: 'Ilha do Cabo ➔ Chicala ➔ Mutamba' },
  });

  // 5. VEGETAÇÃO: COQUEIROS DA ILHA E PALMEIRAS URBANAS
  const buildPalmTree = (x: number, z: number, scale = 1.0) => {
    const palm = new THREE.Group();

    // Tronco curvo de palmeira
    const trunkGeo = new THREE.CylinderGeometry(0.25 * scale, 0.45 * scale, 7 * scale, 8);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x785a3a, roughness: 0.9 });
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.set(0, 3.5 * scale, 0);
    trunk.rotation.z = (Math.random() - 0.5) * 0.15;
    trunk.castShadow = true;
    palm.add(trunk);

    // Folhagem tropical de palmeira (leques)
    const leafGeo = new THREE.ConeGeometry(2.4 * scale, 0.8 * scale, 5);
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.6 });

    for (let i = 0; i < 7; i++) {
      const angle = (i / 7) * Math.PI * 2;
      const leaf = new THREE.Mesh(leafGeo, leafMat);
      leaf.position.set(Math.cos(angle) * 1.4 * scale, 6.8 * scale, Math.sin(angle) * 1.4 * scale);
      leaf.rotation.z = Math.cos(angle) * 0.7;
      leaf.rotation.x = -Math.sin(angle) * 0.7;
      leaf.castShadow = true;
      palm.add(leaf);
    }

    palm.position.set(x, 0, z);
    root.add(palm);
    swayingTrees.push(palm);

    colliders.push(new THREE.Box3().setFromCenterAndSize(
      new THREE.Vector3(x, 2, z),
      new THREE.Vector3(1, 4, 1)
    ));
  };

  // Coqueiros ao longo da Marginal / Ilha
  for (let z = -140; z <= 140; z += 24) {
    buildPalmTree(-34, z, 1.0 + Math.random() * 0.3);
    buildPalmTree(-14, z + 12, 0.9 + Math.random() * 0.2);
  }

  // Palmeiras em Talatona e Praças
  for (let z = 20; z <= 130; z += 28) {
    buildPalmTree(71, z, 1.1);
    buildPalmTree(89, z, 1.1);
  }

  // 6. POSTES DE ILUMINAÇÃO PÚBLICA (Luminárias urbanas de Luanda)
  const buildStreetLamp = (x: number, z: number) => {
    const lampGroup = new THREE.Group();

    // Poste de aço escuro
    const poleGeo = new THREE.CylinderGeometry(0.12, 0.18, 7, 8);
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.7, roughness: 0.3 });
    const pole = new THREE.Mesh(poleGeo, poleMat);
    pole.position.y = 3.5;
    lampGroup.add(pole);

    // Braço arqueado
    const armGeo = new THREE.CylinderGeometry(0.08, 0.08, 1.8, 8);
    armGeo.rotateZ(Math.PI / 3);
    const arm = new THREE.Mesh(armGeo, poleMat);
    arm.position.set(0.6, 6.8, 0);
    lampGroup.add(arm);

    // Cabeça da luminária
    const headGeo = new THREE.BoxGeometry(0.8, 0.2, 0.4);
    const headMat = new THREE.MeshStandardMaterial({
      color: 0xfef08a,
      emissive: 0xfef08a,
      emissiveIntensity: 0.6,
    });
    const head = new THREE.Mesh(headGeo, headMat);
    head.position.set(1.2, 7.1, 0);
    lampGroup.add(head);

    // Luz pontual para ciclo noturno
    const light = new THREE.PointLight(0xfff3c4, 0.8, 25);
    light.position.set(1.2, 6.9, 0);
    light.castShadow = false; // economiza draw calls
    lampGroup.add(light);
    streetLamps.push(light);

    lampGroup.position.set(x, 0, z);
    root.add(lampGroup);

    colliders.push(new THREE.Box3().setFromCenterAndSize(
      new THREE.Vector3(x, 2, z),
      new THREE.Vector3(0.6, 4, 0.6)
    ));
  };

  // Postes ao longo das avenidas
  for (let z = -120; z <= 120; z += 35) {
    buildStreetLamp(3, z);
    buildStreetLamp(90, z);
  }

  // 7. PLACAS DE SINALIZAÇÃO E DESTINOS RODOVIÁRIOS ANGOLANOS
  const buildRoadSign = (x: number, z: number, rotY: number, line1: string, line2: string) => {
    const signGroup = new THREE.Group();

    // Mastro duplo
    for (const sx of [-1.2, 1.2]) {
      const poleGeo = new THREE.CylinderGeometry(0.08, 0.08, 5, 8);
      const poleMat = new THREE.MeshStandardMaterial({ color: 0x64748b });
      const pole = new THREE.Mesh(poleGeo, poleMat);
      pole.position.set(sx, 2.5, 0);
      signGroup.add(pole);
    }

    // Placa verde de autoestrada angolana
    const signCanvas = document.createElement('canvas');
    signCanvas.width = 512;
    signCanvas.height = 180;
    const sctx = signCanvas.getContext('2d')!;
    sctx.fillStyle = '#15803d'; // Verde padrão de sinalização rodoviária
    sctx.fillRect(0, 0, 512, 180);
    sctx.strokeStyle = '#ffffff';
    sctx.lineWidth = 8;
    sctx.strokeRect(6, 6, 500, 168);

    sctx.fillStyle = '#ffffff';
    sctx.font = 'bold 36px sans-serif';
    sctx.textAlign = 'center';
    sctx.fillText(line1, 256, 75);
    sctx.font = '28px sans-serif';
    sctx.fillText(line2, 256, 130);

    const signTex = new THREE.CanvasTexture(signCanvas);
    signTex.colorSpace = THREE.SRGBColorSpace;
    const boardGeo = new THREE.BoxGeometry(3.6, 1.4, 0.15);
    const boardMat = new THREE.MeshStandardMaterial({ map: signTex, roughness: 0.3 });
    const board = new THREE.Mesh(boardGeo, boardMat);
    board.position.set(0, 4.4, 0);
    signGroup.add(board);

    signGroup.position.set(x, 0, z);
    signGroup.rotation.y = rotY;
    root.add(signGroup);

    colliders.push(new THREE.Box3().setFromCenterAndSize(
      new THREE.Vector3(x, 2, z),
      new THREE.Vector3(3.8, 4.5, 0.8)
    ));
  };

  buildRoadSign(80, -15, 0, '← ILHA DE LUANDA', 'VIANA / KILAMBA →');
  buildRoadSign(80, 15, Math.PI, 'TALATONA ↓', 'CENTRO / MAIANGA ↑');

  // 8. EXPANSÃO URBANA: MALHA VIÁRIA, AEROPORTO, ESTÁDIO E PORTO
  // Ruas secundárias em grelha para ligar os bairros e evitar que a cidade pareça um cenário vazio.
  const addCityRoad = (x: number, z: number, width: number, length: number, horizontal: boolean) => {
    const geometry = new THREE.PlaneGeometry(horizontal ? length : width, horizontal ? width : length);
    geometry.rotateX(-Math.PI / 2);
    const material = new THREE.MeshStandardMaterial({
      color: 0x30343a,
      roughness: 0.92,
      polygonOffset: true,
      polygonOffsetFactor: -2,
      polygonOffsetUnits: -2,
    });
    const road = new THREE.Mesh(geometry, material);
    road.position.set(x, 0.065, z);
    road.receiveShadow = true;
    root.add(road);

    // Passeios dos dois lados da rua.
    const sidewalkMat = new THREE.MeshStandardMaterial({ color: 0xb9ad98, roughness: 0.95 });
    for (const side of [-1, 1]) {
      const sidewalkGeo = new THREE.BoxGeometry(
        horizontal ? length : 2.2,
        0.22,
        horizontal ? 2.2 : length
      );
      const sidewalk = new THREE.Mesh(sidewalkGeo, sidewalkMat);
      sidewalk.position.set(
        x + (horizontal ? 0 : side * (width / 2 + 1.1)),
        0.12,
        z + (horizontal ? side * (width / 2 + 1.1) : 0)
      );
      sidewalk.receiveShadow = true;
      root.add(sidewalk);
    }
  };

  // Ligações principais entre Baixa, Maianga, Viana e Talatona.
  [-112, -72, 48, 105, 145].forEach((z) => addCityRoad(78, z, 9, 190, true));
  [18, 48, 118, 158].forEach((x) => addCityRoad(x, 5, 8, 300, false));

  // Rotundas de distribuição de trânsito.
  const addRoundabout = (x: number, z: number, radius: number) => {
    const ring = new THREE.Mesh(
      new THREE.CylinderGeometry(radius, radius, 0.22, 40),
      new THREE.MeshStandardMaterial({ color: 0x4b5563, roughness: 0.9 })
    );
    ring.position.set(x, 0.13, z);
    root.add(ring);
    const island = new THREE.Mesh(
      new THREE.CylinderGeometry(radius * 0.48, radius * 0.48, 0.5, 32),
      new THREE.MeshStandardMaterial({ color: 0x27834a, roughness: 0.85 })
    );
    island.position.set(x, 0.35, z);
    root.add(island);
    for (let i = 0; i < 6; i++) {
      const a = i * Math.PI / 3;
      const shrub = new THREE.Mesh(
        new THREE.SphereGeometry(1.1, 8, 6),
        new THREE.MeshStandardMaterial({ color: 0x166534 })
      );
      shrub.position.set(x + Math.cos(a) * radius * 0.28, 1.2, z + Math.sin(a) * radius * 0.28);
      root.add(shrub);
    }
  };
  addRoundabout(118, 48, 9);
  addRoundabout(158, -72, 8);
  addRoundabout(18, 105, 8);

  // Aeroporto Internacional: pista, taxiway, terminal e torre de controlo.
  const runway = new THREE.Mesh(
    new THREE.PlaneGeometry(92, 20),
    new THREE.MeshStandardMaterial({ color: 0x252a31, roughness: 0.85 })
  );
  runway.rotation.x = -Math.PI / 2;
  runway.position.set(128, 0.08, 112);
  root.add(runway);
  const runwayMarkMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc });
  for (let i = -5; i <= 5; i++) {
    const mark = new THREE.Mesh(new THREE.PlaneGeometry(2.8, 0.35), runwayMarkMat);
    mark.rotation.x = -Math.PI / 2;
    mark.position.set(128 + i * 7, 0.11, 112);
    root.add(mark);
  }
  buildComplex('TerminalAeroporto', 128, 88, 34, 12, 20, '#9ca3af', 0x334155, 'AEROPORTO DE LUANDA', 0x0ea5e9);
  const controlTower = new THREE.Mesh(
    new THREE.CylinderGeometry(2.2, 3, 18, 8),
    new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.35, roughness: 0.4 })
  );
  controlTower.position.set(153, 9, 89);
  root.add(controlTower);
  const controlGlass = new THREE.Mesh(
    new THREE.CylinderGeometry(3, 2.2, 3, 8),
    new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.65, roughness: 0.15 })
  );
  controlGlass.position.set(153, 19, 89);
  root.add(controlGlass);
  interactables.push({
    id: 'aeroporto-luanda', type: 'station', title: 'Aeroporto Internacional de Luanda ✈️',
    subtitle: 'Terminal de passageiros e voos', prompt: '[E] Consultar partidas e chegadas',
    position: [128, 0.5, 76], radius: 7, district: 'viana', data: { service: 'airport' },
  });

  // Estádio e zona desportiva.
  const stadiumBase = new THREE.Mesh(
    new THREE.CylinderGeometry(18, 20, 5, 32, 1, true),
    new THREE.MeshStandardMaterial({ color: 0xd1d5db, roughness: 0.75, side: THREE.DoubleSide })
  );
  stadiumBase.position.set(145, 3, -92);
  root.add(stadiumBase);
  const pitch = new THREE.Mesh(
    new THREE.CircleGeometry(14, 32),
    new THREE.MeshStandardMaterial({ color: 0x27834a, roughness: 0.95 })
  );
  pitch.rotation.x = -Math.PI / 2;
  pitch.position.set(145, 5.55, -92);
  root.add(pitch);
  const pitchLines = new THREE.Mesh(
    new THREE.RingGeometry(4.2, 4.35, 32),
    new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide })
  );
  pitchLines.rotation.x = -Math.PI / 2;
  pitchLines.position.set(145, 5.58, -92);
  root.add(pitchLines);
  interactables.push({
    id: 'estadio-11-novembro', type: 'market', title: 'Estádio 11 de Novembro 🏟️',
    subtitle: 'Complexo desportivo de Luanda', prompt: '[E] Entrar no estádio',
    position: [145, 0.5, -68], radius: 8, district: 'viana', data: { venue: 'stadium' },
  });

  // Porto e zona logística junto à costa.
  buildComplex('TerminalPortuario', -43, -48, 25, 10, 18, '#64748b', 0x1e293b, 'PORTO DE LUANDA', 0xf59e0b);
  for (const [cx, cz] of [[-62, -62], [-28, -62]] as [number, number][]) {
    const crane = new THREE.Group();
    const steel = new THREE.MeshStandardMaterial({ color: 0xef4444, metalness: 0.55, roughness: 0.35 });
    const mast = new THREE.Mesh(new THREE.BoxGeometry(0.8, 18, 0.8), steel);
    mast.position.y = 9;
    crane.add(mast);
    const boom = new THREE.Mesh(new THREE.BoxGeometry(16, 0.7, 0.7), steel);
    boom.position.set(6, 17, 0);
    crane.add(boom);
    const leg = new THREE.Mesh(new THREE.BoxGeometry(8, 0.7, 0.7), steel);
    leg.position.set(0, 1, 0);
    crane.add(leg);
    crane.position.set(cx, 0, cz);
    root.add(crane);
  }
  interactables.push({
    id: 'porto-luanda', type: 'station', title: 'Porto de Luanda ⚓',
    subtitle: 'Terminal marítimo e logística', prompt: '[E] Aceder à zona portuária',
    position: [-43, 0.5, -34], radius: 7, district: 'ilha', data: { service: 'port' },
  });

  // Serviços adicionais para o roleplay: bombeiros, oficina e mercado.
  buildComplex('QuartelBombeiros', 74, 35, 20, 12, 18, '#b91c1c', 0x7f1d1d, 'BOMBEIROS', 0xf97316);
  interactables.push({
    id: 'quartel-bombeiros', type: 'station', title: 'Quartel dos Bombeiros 🚒',
    subtitle: 'Serviço de emergência e salvamento', prompt: '[E] Solicitar assistência',
    position: [74, 0.5, 24], radius: 4, district: 'maianga', data: { service: 'fire' },
  });
  buildComplex('OficinaViana', 158, 18, 22, 10, 18, '#475569', 0xf59e0b, 'OFICINA AUTO', 0xf59e0b);
  interactables.push({
    id: 'oficina-viana', type: 'station', title: 'Oficina Auto Viana 🔧',
    subtitle: 'Reparação e manutenção de veículos', prompt: '[E] Reparar veículo',
    position: [158, 0.5, 7], radius: 4, district: 'viana', data: { service: 'mechanic' },
  });
  buildComplex('MercadoPopular', 118, -38, 24, 9, 18, '#a16207', 0x78350f, 'MERCADO POPULAR', 0xfbbf24);
  interactables.push({
    id: 'mercado-popular', type: 'market', title: 'Mercado Popular 🛒',
    subtitle: 'Comércio local e produtos do dia a dia', prompt: '[E] Visitar mercado',
    position: [118, 0.5, -50], radius: 5, district: 'viana', data: { service: 'market' },
  });

  // DISTRITOS OFICIAIS DE LUANDA NO MAPA
  const districts: District[] = [
    {
      id: 'centro',
      name: 'Centro & Baixa',
      fullName: 'Centro de Luanda & Marginal 4 de Fevereiro',
      description: 'Coração financeiro e histórico de Luanda. Bancos, arranha-céus, ministérios e obelisco nacional.',
      center: [50, -10],
      color: '#3b82f6',
    },
    {
      id: 'ilha',
      name: 'Ilha de Luanda',
      fullName: 'Ilha do Cabo & Orla Marítima Atlântica',
      description: 'Praias de areia dourada, calçadão icónico, coqueiros, esplanadas de peixe fresco (Mufete) e vida noturna.',
      center: [-35, 0],
      color: '#06b6d4',
    },
    {
      id: 'maianga',
      name: 'Maianga',
      fullName: 'Distrito Urbano da Maianga',
      description: 'Bairros residenciais tradicionais, Hospital Josina Machel, Esquadra da Polícia Nacional e embaixadas.',
      center: [35, 35],
      color: '#8b5cf6',
    },
    {
      id: 'viana',
      name: 'Viana',
      fullName: 'Município de Viana & Mercados Populares',
      description: 'Pólo comercial vibrante, mercado dos Congolenses, terminais movimentados de candongueiros e comércio angolano.',
      center: [130, -35],
      color: '#f59e0b',
    },
    {
      id: 'talatona',
      name: 'Talatona',
      fullName: 'Distrito de Talatona & Centro Empresarial',
      description: 'Avenidas modernas, postos Sonangol, condomínios fechados, centros de negócios e compras.',
      center: [100, 60],
      color: '#10b981',
    },
    {
      id: 'kilamba',
      name: 'Centralidade do Kilamba',
      fullName: 'Cidade do Kilamba',
      description: 'Grande expansão urbana contemporânea com blocos residenciais planejados e avenidas arborizadas.',
      center: [80, 120],
      color: '#ec4899',
    },
    {
      id: 'cacuaco',
      name: 'Cacuaco',
      fullName: 'Município de Cacuaco',
      description: 'Zona de pesca e acesso rodoviário ao norte de Luanda, portos pesqueiros e praias tranquilas.',
      center: [80, -120],
      color: '#6366f1',
    },
  ];

  const trafficVehicles = setupLuandaTraffic(root);

  return {
    rootGroup: root,
    colliders,
    interactables,
    districts,
    streetLamps,
    oceanMesh,
    flagMesh,
    swayingTrees,
    trafficVehicles,
    drivableVan,
  };
}
