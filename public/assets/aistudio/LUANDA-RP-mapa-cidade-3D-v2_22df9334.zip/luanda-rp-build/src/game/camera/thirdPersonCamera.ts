/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

export class ThirdPersonCamera {
  public camera: THREE.PerspectiveCamera;

  // Parâmetros orbitais esféricos
  public targetRadius = 4.4; // Distância padrão atrás do jogador
  public currentRadius = 4.4;
  public minRadius = 1.6;
  public maxRadius = 9.0;

  // Ângulos orbitais
  public yaw = 0; // Rotação horizontal (radianos)
  public pitch = 0.22; // Elevação vertical (radianos)
  public minPitch = -0.15; // Não olhar muito por baixo do chão
  public maxPitch = 1.25; // Quase topo da cabeça

  // Vetores de amortecimento
  private currentTarget = new THREE.Vector3();
  private desiredCameraPos = new THREE.Vector3();
  private raycaster = new THREE.Raycaster();
  private manualControlRemaining = 0;
  private readonly followSmoothing = 5.5;

  constructor(fov = 65, aspect = 1.6, near = 0.1, far = 600) {
    this.camera = new THREE.PerspectiveCamera(fov, aspect, near, far);
  }

  // Manipulação de rotação por rato ou toque
  public rotate(deltaX: number, deltaY: number, sensitivity = 0.0035) {
    this.yaw -= deltaX * sensitivity;
    this.pitch = Math.max(this.minPitch, Math.min(this.maxPitch, this.pitch + deltaY * sensitivity));
    this.manualControlRemaining = 2.8;
  }

  // Zoom da câmera (roda do rato ou pinça)
  public zoom(deltaRadius: number) {
    this.targetRadius = Math.max(this.minRadius, Math.min(this.maxRadius, this.targetRadius + deltaRadius));
  }

  public update(
    delta: number,
    playerPos: THREE.Vector3,
    colliders: THREE.Box3[],
    isVehicleMode = false,
    followYaw?: number
  ) {
    if (this.manualControlRemaining > 0) {
      this.manualControlRemaining = Math.max(0, this.manualControlRemaining - delta);
    } else if (followYaw !== undefined) {
      const angleDiff = Math.atan2(Math.sin(followYaw - this.yaw), Math.cos(followYaw - this.yaw));
      this.yaw += angleDiff * Math.min(1, this.followSmoothing * delta);
    }

    // 1. Alvo do foco: ligeiramente acima da cintura/peito do jogador
    const targetHeight = isVehicleMode ? 1.65 : 1.42;
    const targetLookAt = new THREE.Vector3(
      playerPos.x,
      playerPos.y + targetHeight,
      playerPos.z
    );

    // Amortecimento suave do ponto focal
    this.currentTarget.lerp(targetLookAt, Math.min(1, 14 * delta));

    // Distância desejada com ajuste caso esteja em veículo
    const effectiveRadius = isVehicleMode ? this.targetRadius + 2.5 : this.targetRadius;
    this.currentRadius = THREE.MathUtils.damp(this.currentRadius, effectiveRadius, 10, delta);

    // 2. Coordenadas esféricas relativas ao ponto focal
    const cosPitch = Math.cos(this.pitch);
    const sinPitch = Math.sin(this.pitch);
    const sinYaw = Math.sin(this.yaw);
    const cosYaw = Math.cos(this.yaw);

    const relX = this.currentRadius * cosPitch * sinYaw;
    const relY = this.currentRadius * sinPitch;
    const relZ = this.currentRadius * cosPitch * cosYaw;

    this.desiredCameraPos.set(
      this.currentTarget.x + relX,
      this.currentTarget.y + relY,
      this.currentTarget.z + relZ
    );

    // 3. Prevenção de penetração no chão (Altura mínima de segurança)
    if (this.desiredCameraPos.y < 0.35) {
      this.desiredCameraPos.y = 0.35;
    }

    // 4. Verificação de Colisão com Edifícios e Obstáculos (Raycast simples contra Box3)
    const rayOrigin = this.currentTarget.clone();
    const rayDir = new THREE.Vector3().subVectors(this.desiredCameraPos, rayOrigin);
    const rayDist = rayDir.length();
    rayDir.normalize();

    const ray = new THREE.Ray(rayOrigin, rayDir);
    let nearestDist = rayDist;

    for (const box of colliders) {
      const intersect = ray.intersectBox(box, new THREE.Vector3());
      if (intersect) {
        const d = rayOrigin.distanceTo(intersect);
        if (d < nearestDist && d > 0.8) {
          nearestDist = d - 0.25; // margem de segurança
        }
      }
    }

    // Se houver parede bloqueando, puxa a câmera para mais perto do jogador
    if (nearestDist < rayDist) {
      this.desiredCameraPos.copy(rayOrigin).addScaledVector(rayDir, nearestDist);
    }

    // 5. Interpolação suave para a posição final da câmera
    this.camera.position.lerp(this.desiredCameraPos, Math.min(1, 18 * delta));
    this.camera.lookAt(this.currentTarget);
    this.camera.updateMatrixWorld();
  }
}
