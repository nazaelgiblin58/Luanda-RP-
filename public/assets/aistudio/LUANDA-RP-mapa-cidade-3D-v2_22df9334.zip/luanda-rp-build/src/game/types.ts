/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PlayerStats {
  name: string;
  surname: string;
  idNumber: string; // Ex: 007294812LA042
  cashKz: number;
  bankKz: number;
  health: number; // 0 - 100
  energy: number; // 0 - 100
  hunger: number; // 0 - 100
  thirst: number; // 0 - 100
}

export interface PlayerCustomization {
  skinTone: string;
  shirtColor: string;
  pantsColor: string;
  shoesColor: string;
  hairStyle: 'curto' | 'afro' | 'trancas' | 'bone';
  hairColor: string;
  heightScale: number;
}

export type AnimationState = 'idle' | 'walk' | 'run' | 'jump';

export type DistrictId =
  | 'centro'
  | 'ilha'
  | 'maianga'
  | 'viana'
  | 'talatona'
  | 'kilamba'
  | 'cacuaco';

export interface District {
  id: DistrictId;
  name: string;
  fullName: string;
  description: string;
  center: [number, number]; // [x, z]
  color: string;
}

export type InteractableType =
  | 'candongueiro'
  | 'atm'
  | 'food'
  | 'police'
  | 'hospital'
  | 'station'
  | 'monument'
  | 'market';

export interface InteractableObject {
  id: string;
  type: InteractableType;
  title: string;
  subtitle: string;
  prompt: string;
  position: [number, number, number]; // [x, y, z]
  radius: number;
  district: DistrictId;
  data?: Record<string, unknown>;
}

export type WeatherType = 'ensolarado' | 'cacimbo' | 'chuva' | 'pordosol' | 'noite';

export interface GameSettings {
  graphicsQuality: 'low' | 'medium' | 'high';
  cameraSensitivity: number;
  soundVolume: number;
  musicVolume: number;
  shadows: boolean;
  timeSpeed: number; // 1 = normal, 0 = freeze
  weather: WeatherType;
}

