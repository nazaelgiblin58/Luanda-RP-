/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { buildLuandaCity, CityData } from '../city/cityBuilder';
import { PlayerCharacter, PlayerControlsInput } from '../player/playerController';
import { ThirdPersonCamera } from '../camera/thirdPersonCamera';
import { GameSettings, InteractableObject, PlayerCustomization, PlayerStats, WeatherType } from '../types';
import { soundFx } from '../audio/soundFx';

export class GameEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private cameraSystem: ThirdPersonCamera;
  public cityData: CityData;
  public player: PlayerCharacter;

  // Iluminação, Céu e Ambiente
  private sunLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private isSoftwareGl = false;

  // Sistema de Clima & Partículas de Chuva
  public currentWeather: WeatherType = 'ensolarado';
  private rainMesh: THREE.Points | null = null;
  private rainCount = 1500;

  // Modo Veículo Conduzível
  public isDriving = false;

  // Estado do Jogo e Relógio
  public timeOfDay = 15.5; // Inicia às 15h30 em Luanda
  private clock = new THREE.Clock();
  private frameId = 0;
  private isRunning = false;
  private settings: GameSettings;

  // Estado de inputs para o loop unificado
  public currentInput: PlayerControlsInput = {
    forward: false,
    backward: false,
    left: false,
    right: false,
    sprint: false,
    jump: false,
    interact: false,
  };
  public currentStats: PlayerStats;

  // Callbacks para UI (chamados com throttling para alta performance)
  private onNearInteractable?: (obj: InteractableObject | null) => void;
  private onDistrictChange?: (districtName: string) => void;
  private onStatsTick?: (stats: PlayerStats) => void;
  private onTimeUpdate?: (timeString: string, hour: number) => void;
  private onDrivingChange?: (isDriving: boolean) => void;

  private currentDistrict = 'Centro & Baixa';
  private statsTimer = 0;
  private clockThrottleTimer = 0;
  private lastTimeString = '';

  constructor(
    container: HTMLElement,
    customization: PlayerCustomization,
    settings: GameSettings,
    stats: PlayerStats,
    callbacks: {
      onNearInteractable?: (obj: InteractableObject | null) => void;
      onDistrictChange?: (districtName: string) => void;
      onStatsTick?: (stats: PlayerStats) => void;
      onTimeUpdate?: (timeString: string, hour: number) => void;
      onDrivingChange?: (isDriving: boolean) => void;
    }
  ) {
    this.container = container;
    this.settings = settings;
    this.currentStats = stats;
    this.currentWeather = settings.weather || 'ensolarado';
    this.onNearInteractable = callbacks.onNearInteractable;
    this.onDistrictChange = callbacks.onDistrictChange;
    this.onStatsTick = callbacks.onStatsTick;
    this.onTimeUpdate = callbacks.onTimeUpdate;
    this.onDrivingChange = callbacks.onDrivingChange;

    // 1. Deteção de Software WebGL (evita falhas e lag em PCs de entrada)
    this.isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    // 2. Inicialização do WebGLRenderer otimizado
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl && settings.graphicsQuality === 'high',
      powerPreference: 'high-performance',
      alpha: false,
      depth: true,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, settings.graphicsQuality === 'high' ? 1.75 : 1.25)
    );
    this.renderer.setSize(container.clientWidth, container.clientHeight);

    // Sombras controladas para estabilidade de framerate
    if (!this.isSoftwareGl && settings.shadows && settings.graphicsQuality !== 'low') {
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    } else {
      this.renderer.shadowMap.enabled = false;
    }

    container.appendChild(this.renderer.domElement);

    // 3. Cena e Ambiente de Reflexão Studio RoomEnvironment
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x38bdf8); // Céu de Luanda
    this.scene.fog = new THREE.FogExp2(0x38bdf8, 0.007);

    try {
      const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
      this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
      pmremGenerator.dispose();
    } catch {
      // fallback
    }

    // 4. Iluminação 3-Pontos
    this.hemiLight = new THREE.HemisphereLight(0xbae6fd, 0x854d0e, 0.8);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xffedd5, 1.6);
    this.sunLight.position.set(60, 90, 45);
    if (!this.isSoftwareGl && settings.shadows && settings.graphicsQuality !== 'low') {
      this.sunLight.castShadow = true;
      this.sunLight.shadow.mapSize.width = 1024;
      this.sunLight.shadow.mapSize.height = 1024;
      this.sunLight.shadow.camera.near = 10;
      this.sunLight.shadow.camera.far = 240;
      const d = 80;
      this.sunLight.shadow.camera.left = -d;
      this.sunLight.shadow.camera.right = d;
      this.sunLight.shadow.camera.top = d;
      this.sunLight.shadow.camera.bottom = -d;
      this.sunLight.shadow.bias = -0.0005;
      this.sunLight.shadow.normalBias = 0.02;
    }
    this.scene.add(this.sunLight);

    // 5. Câmera Orbital em Terceira Pessoa
    const aspect = container.clientWidth / container.clientHeight;
    this.cameraSystem = new ThirdPersonCamera(60, aspect, 0.1, 500);

    // 6. Construção da Cidade de Luanda, Tráfego e Árvores
    this.cityData = buildLuandaCity();
    this.scene.add(this.cityData.rootGroup);

    // 7. Personagem do Cidadão Angolano
    this.player = new PlayerCharacter(customization);
    this.player.position.set(0, 0, 10);
    this.scene.add(this.player.mesh);

    // 8. Inicializa Partículas de Chuva Tropical
    this.setupRainSystem();

    // 9. Aplica o clima inicial
    this.applyWeather(this.currentWeather);

    // Listener de resize
    window.addEventListener('resize', this.handleResize);

    // Inicia o Loop Mestre Único (evita duplicação e garante 60 FPS estável)
    this.startMasterLoop();
  }

  private setupRainSystem() {
    const rainGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(this.rainCount * 3);

    for (let i = 0; i < this.rainCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 80;
      positions[i * 3 + 1] = Math.random() * 30;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 80;
    }

    rainGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const rainMat = new THREE.PointsMaterial({
      color: 0x93c5fd,
      size: 0.15,
      transparent: true,
      opacity: 0.75,
    });

    this.rainMesh = new THREE.Points(rainGeo, rainMat);
    this.rainMesh.visible = false;
    this.scene.add(this.rainMesh);
  }

  public setWeather(weather: WeatherType) {
    this.currentWeather = weather;
    this.applyWeather(weather);
  }

  private applyWeather(weather: WeatherType) {
    if (weather === 'chuva') {
      if (this.rainMesh) this.rainMesh.visible = true;
      soundFx.startRain();
    } else {
      if (this.rainMesh) this.rainMesh.visible = false;
      soundFx.stopRain();
    }
  }

  // Alterna entre conduzir o Candongueiro e andar a pé
  public toggleDriveCandongueiro() {
    if (this.isDriving) {
      // Sair do veículo
      this.isDriving = false;
      this.player.mesh.visible = true;
      // Posiciona o jogador ao lado da porta do candongueiro
      const vanPos = this.cityData.drivableVan.mesh.position;
      this.player.position.set(vanPos.x - 2.0, 0, vanPos.z);
      this.player.mesh.position.copy(this.player.position);
      if (this.onDrivingChange) this.onDrivingChange(false);
      soundFx.playInteract();
    } else {
      // Entrar no veículo
      this.isDriving = true;
      this.player.mesh.visible = false;
      if (this.onDrivingChange) this.onDrivingChange(true);
      soundFx.playCandongueiroHorn();
      soundFx.playEngineRev(1.1);
    }
  }

  public getInteractables(): InteractableObject[] {
    return this.cityData.interactables;
  }

  public rotateCamera(dx: number, dy: number) {
    this.cameraSystem.rotate(dx, dy, this.settings.cameraSensitivity * 0.0035);
  }

  public zoomCamera(delta: number) {
    this.cameraSystem.zoom(delta);
  }

  public updateSettings(newSettings: GameSettings) {
    this.settings = newSettings;
    if (newSettings.weather !== this.currentWeather) {
      this.setWeather(newSettings.weather);
    }
    if (this.renderer) {
      this.renderer.setPixelRatio(
        this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, newSettings.graphicsQuality === 'high' ? 1.75 : 1.25)
      );
      this.renderer.shadowMap.enabled = !this.isSoftwareGl && newSettings.shadows && newSettings.graphicsQuality !== 'low';
    }
  }

  private handleResize = () => {
    if (!this.container || !this.renderer) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.cameraSystem.camera.aspect = width / height;
    this.cameraSystem.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private startMasterLoop() {
    this.isRunning = true;
    this.clock.start();

    const tick = () => {
      if (!this.isRunning) return;

      // Delta de tempo preciso e estável
      const delta = Math.min(this.clock.getDelta(), 0.06);

      // 1. Atualiza toda a simulação do jogo (Física, Carros, Árvores, Clima, Relógio)
      this.simulateFrame(delta);

      // 2. Renderiza a cena com a câmera
      this.renderer.render(this.scene, this.cameraSystem.camera);

      // 3. Pacing do próximo frame
      if (this.isSoftwareGl) {
        this.afterDraw(tick);
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    if (this.isSoftwareGl) {
      this.afterDraw(tick);
    } else {
      this.frameId = requestAnimationFrame(tick);
    }
  }

  private afterDraw(cb: () => void) {
    try {
      const gl = this.renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          this.frameId = window.setTimeout(poll, 6);
        } else {
          gl.deleteSync(sync);
          this.frameId = window.setTimeout(cb, 40);
        }
      };
      this.frameId = window.setTimeout(poll, 6);
    } catch {
      this.frameId = window.setTimeout(cb, 50);
    }
  }

  private simulateFrame(delta: number) {
    const time = this.clock.getElapsedTime();
    const input = this.currentInput;
    const van = this.cityData.drivableVan;

    // A. MODO CONDUÇÃO DO CANDONGUEIRO vs MODO A PÉ
    if (this.isDriving && van) {
      // Física de Condução do Candongueiro de Luanda
      let accel = 0;
      if (input.forward) accel += 1;
      if (input.backward) accel -= 0.6;

      if (accel !== 0) {
        van.velocity = THREE.MathUtils.damp(van.velocity, accel * van.maxSpeed, 4, delta);
        if (Math.random() < 0.02) {
          soundFx.playEngineRev(1.0 + Math.abs(van.velocity) / van.maxSpeed * 0.4);
        }
      } else {
        // Fricção natural e travão
        van.velocity = THREE.MathUtils.damp(van.velocity, 0, input.jump ? 9 : 2.5, delta);
      }

      // Direção / Esterçamento
      let steerInput = 0;
      if (input.left) steerInput += 1;
      if (input.right) steerInput -= 1;

      van.steering = THREE.MathUtils.damp(van.steering, steerInput * 0.45, 10, delta);

      if (Math.abs(van.velocity) > 0.1) {
        const turnSpeed = (van.velocity / van.maxSpeed) * (steerInput * 1.8);
        van.rotationY += turnSpeed * delta;
      }

      // Atualiza posição do veículo pelo vetor de direção
      const forwardX = Math.sin(van.rotationY);
      const forwardZ = Math.cos(van.rotationY);

      van.position.x += forwardX * van.velocity * delta;
      van.position.z += forwardZ * van.velocity * delta;

      // Limites das estradas
      van.position.x = Math.max(-150, Math.min(150, van.position.x));
      van.position.z = Math.max(-150, Math.min(150, van.position.z));

      van.mesh.position.copy(van.position);
      van.mesh.rotation.y = van.rotationY;

      // Rotação das rodas do candongueiro
      const wheelRoll = (van.velocity / 0.42) * delta;
      for (let i = 0; i < van.wheels.length; i++) {
        van.wheels[i].rotation.x += wheelRoll;
        // As rodas dianteiras viram na direção do volante
        if (i < 2) {
          van.wheels[i].rotation.y = van.steering;
        }
      }

      // Câmera segue o candongueiro
      this.cameraSystem.update(delta, van.position, this.cityData.colliders, true, van.rotationY + Math.PI);

      // Atualiza posição lógica do jogador para estar dentro do veículo
      this.player.position.copy(van.position);
    } else {
      // Modo a Pé normal: Atualiza Personagem (movimentação, saltos, colisões)
      this.player.update(
        delta,
        input,
        this.cameraSystem.yaw,
        this.cityData.colliders,
        this.currentStats
      );

      // Câmera orbital em 3ª pessoa segue o jogador
      this.cameraSystem.update(
        delta,
        this.player.position,
        this.cityData.colliders,
        false,
        this.player.rotationY + Math.PI
      );
    }

    // B. TRÁFEGO DE CARROS AUTOMÁTICO EM LUANDA
    for (const car of this.cityData.trafficVehicles) {
      if (car.axis === 'z') {
        car.mesh.position.z += car.speed * car.direction * delta;
        if (car.mesh.position.z > car.maxCoord) {
          car.direction = -1;
          car.mesh.rotation.y = Math.PI;
        } else if (car.mesh.position.z < car.minCoord) {
          car.direction = 1;
          car.mesh.rotation.y = 0;
        }
      } else {
        car.mesh.position.x += car.speed * car.direction * delta;
        if (car.mesh.position.x > car.maxCoord) {
          car.direction = -1;
          car.mesh.rotation.y = -Math.PI / 2;
        } else if (car.mesh.position.x < car.minCoord) {
          car.direction = 1;
          car.mesh.rotation.y = Math.PI / 2;
        }
      }

      // Rotação contínua das rodas dos carros de tráfego
      const roll = (car.speed / 0.35) * delta;
      for (const w of car.wheels) {
        w.rotation.x += roll;
      }
    }

    // C. ANIMAÇÃO DE ÁRVORES E COQUEIROS (BALANÇO SUAVE DO VENTO TROPICAL)
    const swayAmp = this.currentWeather === 'chuva' ? 0.07 : 0.035;
    const swayFreq = this.currentWeather === 'chuva' ? 2.5 : 1.6;
    for (let i = 0; i < this.cityData.swayingTrees.length; i++) {
      const tree = this.cityData.swayingTrees[i];
      tree.rotation.z = Math.sin(time * swayFreq + i * 0.45) * swayAmp;
      tree.rotation.x = Math.cos(time * (swayFreq * 0.8) + i * 0.3) * (swayAmp * 0.7);
    }

    // D. SISTEMA DE CHUVA (SE ATIVO)
    if (this.currentWeather === 'chuva' && this.rainMesh) {
      const positions = this.rainMesh.geometry.attributes.position.array as Float32Array;
      const focusX = this.isDriving ? van.position.x : this.player.position.x;
      const focusZ = this.isDriving ? van.position.z : this.player.position.z;

      for (let i = 0; i < this.rainCount; i++) {
        // Queda das gotas de chuva
        positions[i * 3 + 1] -= 22 * delta;

        // Se tocar no chão, reinicia no topo ao redor do foco do jogador
        if (positions[i * 3 + 1] < 0) {
          positions[i * 3 + 1] = 26 + Math.random() * 8;
          positions[i * 3] = focusX + (Math.random() - 0.5) * 60;
          positions[i * 3 + 2] = focusZ + (Math.random() - 0.5) * 60;
        }
      }
      this.rainMesh.geometry.attributes.position.needsUpdate = true;
    }

    // E. ONDULAÇÃO DO OCEANO ATLÂNTICO NA ILHA DE LUANDA
    if (this.cityData.oceanMesh) {
      this.cityData.oceanMesh.position.y = -0.4 + Math.sin(time * 1.5) * 0.08;
    }

    // F. CICLO HORÁRIO & CLIMAS DE LUANDA
    this.updateDayNightAndWeather(delta);

    // G. VERIFICAÇÃO DE PROXIMIDADE COM OBJETOS INTERATIVOS
    const checkPos = this.isDriving ? van.position : this.player.position;
    let nearestInteractable: InteractableObject | null = null;
    let minDistance = Infinity;

    for (const obj of this.cityData.interactables) {
      const [ox, , oz] = obj.position;
      const dx = checkPos.x - ox;
      const dz = checkPos.z - oz;
      const dist = Math.sqrt(dx * dx + dz * dz);

      if (dist <= obj.radius && dist < minDistance) {
        minDistance = dist;
        nearestInteractable = obj;
      }
    }

    if (this.onNearInteractable) {
      this.onNearInteractable(nearestInteractable);
    }

    // H. ATUALIZAÇÃO DO DISTRITO ATUAL
    let nearestDistrictName = 'Centro & Baixa';
    let nearestDistDist = Infinity;

    for (const district of this.cityData.districts) {
      const [cx, cz] = district.center;
      const dx = checkPos.x - cx;
      const dz = checkPos.z - cz;
      const dist = Math.sqrt(dx * dx + dz * dz);

      if (dist < nearestDistDist) {
        nearestDistDist = dist;
        nearestDistrictName = district.name;
      }
    }

    if (nearestDistrictName !== this.currentDistrict) {
      this.currentDistrict = nearestDistrictName;
      if (this.onDistrictChange) {
        this.onDistrictChange(nearestDistrictName);
      }
    }

    // I. DRENAGEM E RECUPERAÇÃO DE ENERGIA / VITALIDADE (THROTTLED A 1s)
    this.statsTimer += delta;
    if (this.statsTimer >= 1.0) {
      this.statsTimer = 0;
      const updatedStats = { ...this.currentStats };

      if (!this.isDriving && input.sprint && (input.forward || input.backward || input.left || input.right)) {
        updatedStats.energy = Math.max(0, updatedStats.energy - 3.0);
      } else {
        updatedStats.energy = Math.min(100, updatedStats.energy + 4.0);
      }

      updatedStats.thirst = Math.max(0, updatedStats.thirst - 0.15);
      updatedStats.hunger = Math.max(0, updatedStats.hunger - 0.12);

      this.currentStats = updatedStats;
      if (this.onStatsTick) {
        this.onStatsTick(updatedStats);
      }
    }

    // J. RELÓGIO DE LUANDA ATUALIZADO COM THROTTLE (SEM RE-RENDERS DA UI A 60 FPS)
    this.clockThrottleTimer += delta;
    if (this.clockThrottleTimer >= 0.5) {
      this.clockThrottleTimer = 0;
      const hours = Math.floor(this.timeOfDay);
      const minutes = Math.floor((this.timeOfDay - hours) * 60);
      const timeStr = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;

      if (timeStr !== this.lastTimeString) {
        this.lastTimeString = timeStr;
        if (this.onTimeUpdate) {
          this.onTimeUpdate(timeStr, this.timeOfDay);
        }
      }
    }
  }

  private updateDayNightAndWeather(delta: number) {
    if (this.settings.timeSpeed > 0) {
      // 1 hora de jogo a cada 75 segundos reais
      this.timeOfDay = (this.timeOfDay + delta * 0.018 * this.settings.timeSpeed) % 24;
    }

    const t = this.timeOfDay;
    const sunAngle = ((t - 6) / 24) * Math.PI * 2;
    const sunHeight = Math.sin(sunAngle);
    const sunDist = 120;

    this.sunLight.position.set(
      Math.cos(sunAngle) * sunDist,
      Math.max(-20, sunHeight * sunDist),
      40
    );

    let skyColor: THREE.Color;
    let sunIntensity = 1.6;
    let streetLampIntensity = 0;
    let fogDensity = 0.007;

    // Adaptação conforme o Clima selecionado
    if (this.currentWeather === 'cacimbo') {
      // Cacimbo: Nevoeiro marítimo típico de Luanda, cinza/azul suave
      skyColor = new THREE.Color(0x94a3b8);
      this.sunLight.color.set(0xe2e8f0);
      this.hemiLight.color.set(0xcbd5e1);
      this.hemiLight.groundColor.set(0x64748b);
      sunIntensity = 0.8;
      fogDensity = 0.018;
      streetLampIntensity = 0.3;
    } else if (this.currentWeather === 'chuva') {
      // Chuva Tropical: Céu escuro tempestuoso com chuva caindo
      skyColor = new THREE.Color(0x334155);
      this.sunLight.color.set(0x64748b);
      this.hemiLight.color.set(0x475569);
      this.hemiLight.groundColor.set(0x1e293b);
      sunIntensity = 0.5;
      fogDensity = 0.015;
      streetLampIntensity = 0.6;
    } else if (this.currentWeather === 'pordosol' || (this.currentWeather === 'ensolarado' && t >= 17 && t < 19.5)) {
      // Pôr-do-Sol Dourado sobre a Baía de Luanda
      const p = (t >= 17 && t < 19.5) ? (t - 17) / 2.5 : 0.7;
      skyColor = new THREE.Color().lerpColors(new THREE.Color(0xf97316), new THREE.Color(0x701a75), p);
      this.sunLight.color.set(0xfb923c);
      sunIntensity = 1.0;
      fogDensity = 0.008;
      streetLampIntensity = 0.5;
    } else if (this.currentWeather === 'noite' || (this.currentWeather === 'ensolarado' && (t >= 19.5 || t < 5.5))) {
      // Noite em Luanda: Céu anil estrelado, postes e faróis ligados
      skyColor = new THREE.Color(0x090d16);
      this.sunLight.color.set(0x93c5fd);
      this.hemiLight.color.set(0x1e293b);
      this.hemiLight.groundColor.set(0x020617);
      sunIntensity = 0.25;
      fogDensity = 0.009;
      streetLampIntensity = 1.0;
    } else {
      // Ensolarado Tropical
      skyColor = new THREE.Color(0x38bdf8);
      this.sunLight.color.set(0xffedd5);
      this.hemiLight.color.set(0xbae6fd);
      this.hemiLight.groundColor.set(0x854d0e);
      sunIntensity = 1.7;
      fogDensity = 0.006;
      streetLampIntensity = 0;
    }

    this.scene.background = skyColor;
    if (this.scene.fog) {
      this.scene.fog.color = skyColor;
      (this.scene.fog as THREE.FogExp2).density = fogDensity;
    }
    this.sunLight.intensity = Math.max(0.1, sunIntensity);

    // Iluminação dos postes públicos
    for (const lamp of this.cityData.streetLamps) {
      lamp.intensity = streetLampIntensity;
    }
  }

  public teleport(x: number, z: number) {
    if (this.isDriving && this.cityData.drivableVan) {
      this.cityData.drivableVan.position.set(x, 0, z);
      this.cityData.drivableVan.mesh.position.copy(this.cityData.drivableVan.position);
      this.cityData.drivableVan.velocity = 0;
    }
    this.player.position.set(x, 0, z);
    this.player.mesh.position.copy(this.player.position);
  }

  public destroy() {
    this.isRunning = false;
    soundFx.stopRain();
    window.removeEventListener('resize', this.handleResize);
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    this.renderer.dispose();
  }
}
