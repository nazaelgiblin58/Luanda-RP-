/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class SoundManager {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private isRadioPlaying = false;
  private radioInterval: number | null = null;
  private radioStep = 0;
  private volume = 0.5;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.value = this.volume;
        this.masterGain.connect(this.ctx.destination);

        this.musicGain = this.ctx.createGain();
        this.musicGain.gain.value = 0.25;
        this.musicGain.connect(this.masterGain);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain) {
      this.masterGain.gain.value = this.volume;
    }
  }

  // Passos de caminhada
  public playFootstep(isRunning: boolean) {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(isRunning ? 320 : 240, this.ctx.currentTime);

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(isRunning ? 90 : 70, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(30, this.ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(isRunning ? 0.12 : 0.07, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.08);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.09);
    } catch {
      // Audio fallback silent
    }
  }

  // Som de Salto
  public playJump() {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(140, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(320, this.ctx.currentTime + 0.15);

      gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.15);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.16);
    } catch {
      // fallback
    }
  }

  // Som de Aterragem
  public playLand() {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(120, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(40, this.ctx.currentTime + 0.12);

      gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.12);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.13);
    } catch {
      // fallback
    }
  }

  // Buzina clássica do Candongueiro (Toyota HiAce de Luanda: "Bii-Bii!")
  public playCandongueiroHorn() {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;

      const playChirp = (delayMs: number, freq1: number, freq2: number, duration: number) => {
        setTimeout(() => {
          if (!this.ctx || !this.masterGain) return;
          const osc1 = this.ctx.createOscillator();
          const osc2 = this.ctx.createOscillator();
          const gain = this.ctx.createGain();

          osc1.type = 'sawtooth';
          osc2.type = 'triangle';
          osc1.frequency.setValueAtTime(freq1, this.ctx.currentTime);
          osc2.frequency.setValueAtTime(freq2, this.ctx.currentTime);

          gain.gain.setValueAtTime(0.18, this.ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);

          osc1.connect(gain);
          osc2.connect(gain);
          gain.connect(this.masterGain);

          osc1.start();
          osc2.start();
          osc1.stop(this.ctx.currentTime + duration);
          osc2.stop(this.ctx.currentTime + duration);
        }, delayMs);
      };

      // Dois toques rápidos característicos
      playChirp(0, 440, 554, 0.12);
      playChirp(160, 440, 554, 0.16);
    } catch {
      // fallback
    }
  }

  // Som de Multicaixa ATM / Dinheiro Kwanza
  public playAtmCash() {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;

      const now = this.ctx.currentTime;
      for (let i = 0; i < 4; i++) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1200 + i * 150, now + i * 0.08);
        gain.gain.setValueAtTime(0.1, now + i * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.05);

        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(now + i * 0.08);
        osc.stop(now + i * 0.08 + 0.06);
      }
    } catch {
      // fallback
    }
  }

  // Som de Interação / Clique
  public playInteract() {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(520, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, this.ctx.currentTime + 0.1);

      gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.1);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.11);
    } catch {
      // fallback
    }
  }

  // Rádio Luanda FM: Ritmo Kizomba / Semba procedural sintetizado
  public toggleRadio(): boolean {
    this.initContext();
    if (this.isRadioPlaying) {
      this.stopRadio();
      return false;
    } else {
      this.startRadio();
      return true;
    }
  }

  public getRadioPlaying(): boolean {
    return this.isRadioPlaying;
  }

  private startRadio() {
    if (!this.ctx || !this.musicGain) return;
    this.isRadioPlaying = true;
    this.radioStep = 0;

    // Ritmo sincopado clássico semba/kizomba: 95 BPM (~158ms por semicolcheia)
    const stepTime = 158;

    this.radioInterval = window.setInterval(() => {
      if (!this.ctx || !this.musicGain || !this.isRadioPlaying) return;
      const t = this.ctx.currentTime;
      const s = this.radioStep % 16;

      // Kick drum sincopado: tempos 0, 6, 8, 14
      if (s === 0 || s === 6 || s === 8 || s === 14) {
        const kick = this.ctx.createOscillator();
        const kgain = this.ctx.createGain();
        kick.type = 'sine';
        kick.frequency.setValueAtTime(140, t);
        kick.frequency.exponentialRampToValueAtTime(45, t + 0.12);
        kgain.gain.setValueAtTime(0.25, t);
        kgain.gain.exponentialRampToValueAtTime(0.001, t + 0.13);
        kick.connect(kgain);
        kgain.connect(this.musicGain);
        kick.start(t);
        kick.stop(t + 0.14);
      }

      // Shaker / Maracas (ruído sutil)
      if (s % 2 === 0 || s % 3 === 0) {
        const shkOsc = this.ctx.createOscillator();
        const shkGain = this.ctx.createGain();
        shkOsc.type = 'triangle';
        shkOsc.frequency.setValueAtTime(800 + (s * 30), t);
        shkGain.gain.setValueAtTime(0.03, t);
        shkGain.gain.exponentialRampToValueAtTime(0.0001, t + 0.04);
        shkOsc.connect(shkGain);
        shkGain.connect(this.musicGain);
        shkOsc.start(t);
        shkOsc.stop(t + 0.05);
      }

      // Bassline quente (notas em escala pentatônica menor/dórica suave)
      const bassNotes = [110, 110, 130.8, 146.8, 164.8, 146.8, 130.8, 110];
      if (s === 2 || s === 4 || s === 10 || s === 12) {
        const bass = this.ctx.createOscillator();
        const bgain = this.ctx.createGain();
        const bfilter = this.ctx.createBiquadFilter();
        bfilter.type = 'lowpass';
        bfilter.frequency.value = 350;

        bass.type = 'sawtooth';
        const note = bassNotes[(Math.floor(this.radioStep / 4)) % bassNotes.length];
        bass.frequency.setValueAtTime(note, t);

        bgain.gain.setValueAtTime(0.08, t);
        bgain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);

        bass.connect(bfilter);
        bfilter.connect(bgain);
        bgain.connect(this.musicGain);
        bass.start(t);
        bass.stop(t + 0.23);
      }

      this.radioStep++;
    }, stepTime);
  }

  // Som de Chuva Tropical em Luanda (Procedural Pink/White Noise filtrado)
  private rainNode: AudioBufferSourceNode | null = null;
  private rainGain: GainNode | null = null;

  public startRain() {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain || this.rainNode) return;

      const bufferSize = this.ctx.sampleRate * 2;
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        // Pink noise filter approximation
        lastOut = (lastOut + 0.02 * white) / 1.02;
        data[i] = lastOut * 3.5;
      }

      this.rainNode = this.ctx.createBufferSource();
      this.rainNode.buffer = buffer;
      this.rainNode.loop = true;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 1200;

      this.rainGain = this.ctx.createGain();
      this.rainGain.gain.setValueAtTime(0.01, this.ctx.currentTime);
      this.rainGain.gain.linearRampToValueAtTime(0.18, this.ctx.currentTime + 1.2);

      this.rainNode.connect(filter);
      filter.connect(this.rainGain);
      this.rainGain.connect(this.masterGain);
      this.rainNode.start();
    } catch {
      // fallback
    }
  }

  public stopRain() {
    if (this.rainGain && this.ctx) {
      try {
        this.rainGain.gain.linearRampToValueAtTime(0.001, this.ctx.currentTime + 0.6);
        setTimeout(() => {
          if (this.rainNode) {
            this.rainNode.stop();
            this.rainNode.disconnect();
            this.rainNode = null;
          }
          this.rainGain = null;
        }, 700);
      } catch {
        this.rainNode = null;
        this.rainGain = null;
      }
    }
  }

  // Som de motor acelerando (Candongueiro / Carro)
  public playEngineRev(pitchMultiplier = 1.0) {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(450 * pitchMultiplier, this.ctx.currentTime);

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(65 * pitchMultiplier, this.ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(140 * pitchMultiplier, this.ctx.currentTime + 0.3);

      gain.gain.setValueAtTime(0.14, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.35);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.36);
    } catch {
      // fallback
    }
  }

  private stopRadio() {
    this.isRadioPlaying = false;
    if (this.radioInterval !== null) {
      clearInterval(this.radioInterval);
      this.radioInterval = null;
    }
  }
}

export const soundFx = new SoundManager();
