/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine } from './game/engine/gameEngine';
import { GameSettings, InteractableObject, PlayerCustomization, PlayerStats, WeatherType } from './game/types';
import { GameHUD } from './components/hud/GameHUD';
import { StartScreen } from './components/screens/StartScreen';
import { IdentityModal } from './components/modals/IdentityModal';
import { AtmModal } from './components/modals/AtmModal';
import { FoodModal } from './components/modals/FoodModal';
import { VehicleModal } from './components/modals/VehicleModal';
import { MapModal } from './components/modals/MapModal';
import { SettingsModal } from './components/modals/SettingsModal';
import { soundFx } from './game/audio/soundFx';

type ActiveModal = 'start' | 'identity' | 'atm' | 'food' | 'vehicle' | 'map' | 'settings' | null;

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Estado do Jogador
  const [stats, setStats] = useState<PlayerStats>({
    name: 'Mauro',
    surname: 'dos Santos',
    idNumber: '007294812LA042',
    cashKz: 5000,
    bankKz: 45000,
    health: 100,
    energy: 100,
    hunger: 85,
    thirst: 80,
  });

  const [customization, setCustomization] = useState<PlayerCustomization>({
    skinTone: '#4a2c17',
    shirtColor: '#dc2626',
    pantsColor: '#1e3a8a', // Azul Ganga
    shoesColor: '#ffffff',
    hairStyle: 'afro',
    hairColor: '#171717',
    heightScale: 1.0,
  });

  const [settings, setSettings] = useState<GameSettings>({
    graphicsQuality: 'medium', // Equilíbrio perfeito entre qualidade e 60 FPS
    cameraSensitivity: 1.0,
    soundVolume: 0.6,
    musicVolume: 0.4,
    shadows: false, // Sem sombras pesadas para garantir fluidez total em todos os dispositivos
    timeSpeed: 1.0,
    weather: 'ensolarado',
  });

  // Estado de Ambiente e Navegação
  const [currentDistrict, setCurrentDistrict] = useState('Centro & Baixa');
  const [timeString, setTimeString] = useState('15:30');
  const [timeOfDay, setTimeOfDay] = useState(15.5);
  const [currentWeather, setCurrentWeather] = useState<WeatherType>('ensolarado');
  const [isDriving, setIsDriving] = useState(false);
  const [nearInteractable, setNearInteractable] = useState<InteractableObject | null>(null);
  const [activeModal, setActiveModal] = useState<ActiveModal>('start');
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const [kioskTitle, setKioskTitle] = useState('Quiosque Gastronómico da Ilha');

  const nearInteractableRef = useRef(nearInteractable);
  nearInteractableRef.current = nearInteractable;

  const isDrivingRef = useRef(isDriving);
  isDrivingRef.current = isDriving;

  // Deteção de dispositivo touch
  useEffect(() => {
    setIsTouchDevice('ontouchstart' in window || navigator.maxTouchPoints > 0);
  }, []);

  // Inicialização Única do Game Engine Three.js
  useEffect(() => {
    if (!canvasMountRef.current) return;

    const engine = new GameEngine(
      canvasMountRef.current,
      customization,
      settings,
      stats,
      {
        onNearInteractable: (obj) => {
          setNearInteractable(obj);
        },
        onDistrictChange: (districtName) => {
          setCurrentDistrict(districtName);
        },
        onStatsTick: (newStats) => {
          setStats(newStats);
        },
        onTimeUpdate: (str, hour) => {
          // Atualizado com throttle (apenas 1 vez por segundo, sem re-render a 60 FPS!)
          setTimeString(str);
          setTimeOfDay(hour);
        },
        onDrivingChange: (driving) => {
          setIsDriving(driving);
        },
      }
    );

    engineRef.current = engine;

    return () => {
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  // Alterna condução do Candongueiro
  const handleToggleDrive = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.toggleDriveCandongueiro();
    }
  }, []);

  // Manipulador de Interação
  const triggerInteraction = useCallback(() => {
    if (isDrivingRef.current) {
      handleToggleDrive();
      return;
    }

    const item = nearInteractableRef.current;
    if (!item) return;

    soundFx.playInteract();

    if (item.type === 'candongueiro') {
      // Se for o candongueiro da paragem baixa, pode conduzir diretamente ou abrir o menu de linhas
      if (item.data?.isDrivable) {
        handleToggleDrive();
      } else {
        setActiveModal('vehicle');
      }
    } else if (item.type === 'atm') {
      setActiveModal('atm');
    } else if (item.type === 'food' || item.type === 'market') {
      setKioskTitle(item.title);
      setActiveModal('food');
    } else if (item.type === 'police') {
      alert(`Polícia Nacional de Luanda 🚓: "Comando em prontidão. Mantenha a ordem na capital!"`);
    } else if (item.type === 'hospital') {
      soundFx.playInteract();
      setStats((prev) => ({ ...prev, health: 100 }));
      alert(`Hospital Josina Machel 🏥: Saúde restaurada a 100%!`);
    } else if (item.type === 'monument') {
      soundFx.playCandongueiroHorn();
      alert(`Monumento da Independência 🇦🇴: "Paz e prosperidade ao povo angolano!"`);
    }
  }, [handleToggleDrive]);

  // Teclado PC: alimenta diretamente o engine.currentInput sem passar por React setState
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      const eng = engineRef.current;
      if (!eng) return;

      const key = e.key.toLowerCase();
      if (key === 'w' || key === 'arrowup') eng.currentInput.forward = true;
      if (key === 's' || key === 'arrowdown') eng.currentInput.backward = true;
      if (key === 'a' || key === 'arrowleft') eng.currentInput.left = true;
      if (key === 'd' || key === 'arrowright') eng.currentInput.right = true;
      if (key === 'shift') eng.currentInput.sprint = true;
      if (key === ' ') {
        e.preventDefault();
        eng.currentInput.jump = true;
      }
      if (key === 'e') {
        eng.currentInput.interact = true;
        triggerInteraction();
      }
      if (key === 'h') {
        if (isDrivingRef.current) {
          soundFx.playCandongueiroHorn();
        }
      }
      if (key === 'm') {
        setActiveModal((prev) => (prev === 'map' ? null : 'map'));
      }
      if (key === 'b') {
        setActiveModal((prev) => (prev === 'atm' ? null : 'atm'));
      }
      if (key === 'c') {
        setActiveModal((prev) => (prev === 'identity' ? null : 'identity'));
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const eng = engineRef.current;
      if (!eng) return;

      const key = e.key.toLowerCase();
      if (key === 'w' || key === 'arrowup') eng.currentInput.forward = false;
      if (key === 's' || key === 'arrowdown') eng.currentInput.backward = false;
      if (key === 'a' || key === 'arrowleft') eng.currentInput.left = false;
      if (key === 'd' || key === 'arrowright') eng.currentInput.right = false;
      if (key === 'shift') eng.currentInput.sprint = false;
      if (key === ' ') eng.currentInput.jump = false;
      if (key === 'e') eng.currentInput.interact = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [triggerInteraction]);

  // Manipulação de Rato / Touch para Câmera 360°
  const isPointerDownRef = useRef(false);
  const lastPointerXRef = useRef(0);
  const lastPointerYRef = useRef(0);

  const handlePointerDown = (e: React.PointerEvent) => {
    if (e.button !== 0) return;
    isPointerDownRef.current = true;
    lastPointerXRef.current = e.clientX;
    lastPointerYRef.current = e.clientY;
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch { /* fallback */ }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isPointerDownRef.current || !engineRef.current) return;
    const dx = e.clientX - lastPointerXRef.current;
    const dy = e.clientY - lastPointerYRef.current;
    lastPointerXRef.current = e.clientX;
    lastPointerYRef.current = e.clientY;

    engineRef.current.rotateCamera(dx, dy);
  };

  const handlePointerUp = (e?: React.PointerEvent) => {
    isPointerDownRef.current = false;
    if (e) {
      try {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
      } catch { /* fallback */ }
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (!engineRef.current) return;
    e.preventDefault();
    engineRef.current.zoomCamera(e.deltaY * 0.004);
  };

  // Touch Actions para Android
  const handleTouchAction = (action: 'forward' | 'backward' | 'left' | 'right' | 'sprint' | 'jump' | 'interact' | 'horn') => {
    const eng = engineRef.current;
    if (!eng) return;

    if (action === 'forward') {
      eng.currentInput.forward = true;
      setTimeout(() => { if (eng) eng.currentInput.forward = false; }, 300);
    } else if (action === 'backward') {
      eng.currentInput.backward = true;
      setTimeout(() => { if (eng) eng.currentInput.backward = false; }, 300);
    } else if (action === 'left') {
      eng.currentInput.left = true;
      setTimeout(() => { if (eng) eng.currentInput.left = false; }, 300);
    } else if (action === 'right') {
      eng.currentInput.right = true;
      setTimeout(() => { if (eng) eng.currentInput.right = false; }, 300);
    } else if (action === 'sprint') {
      eng.currentInput.sprint = !eng.currentInput.sprint;
    } else if (action === 'jump') {
      eng.currentInput.jump = true;
      setTimeout(() => { if (eng) eng.currentInput.jump = false; }, 180);
    } else if (action === 'interact') {
      triggerInteraction();
    } else if (action === 'horn') {
      soundFx.playCandongueiroHorn();
    }
  };

  // Teletransporte de Distritos
  const handleTeleport = (x: number, z: number, districtName: string) => {
    if (engineRef.current) {
      engineRef.current.teleport(x, z);
      setCurrentDistrict(districtName);
    }
  };

  // Live Update de Calças e Roupas no Personagem (Atualização imediata ao clicar!)
  const handleLiveCustomization = (newCust: PlayerCustomization) => {
    setCustomization(newCust);
    if (engineRef.current) {
      engineRef.current.player.updateCustomization(newCust);
    }
  };

  // Salvar Identidade
  const handleSaveIdentity = (newStats: PlayerStats, newCust: PlayerCustomization) => {
    setStats(newStats);
    setCustomization(newCust);
    if (engineRef.current) {
      engineRef.current.player.updateCustomization(newCust);
      engineRef.current.currentStats = newStats;
    }
  };

  // Ajuste de Clima
  const handleSetWeather = (w: WeatherType) => {
    setCurrentWeather(w);
    setSettings((prev) => ({ ...prev, weather: w }));
    if (engineRef.current) {
      engineRef.current.setWeather(w);
    }
  };

  // Ajuste de Horas
  const handleSetTimeOfDay = (hour: number) => {
    setTimeOfDay(hour);
    if (engineRef.current) {
      engineRef.current.timeOfDay = hour;
    }
  };

  const handleUpdateSettings = (newSettings: GameSettings) => {
    setSettings(newSettings);
    if (newSettings.weather !== currentWeather) {
      setCurrentWeather(newSettings.weather);
    }
    if (engineRef.current) {
      engineRef.current.updateSettings(newSettings);
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black font-sans select-none">
      {/* 1. CONTAINER WEBGL DEDICADO THREE.JS */}
      <div
        ref={canvasMountRef}
        className="absolute inset-0 cursor-grab active:cursor-grabbing touch-none"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        onWheel={handleWheel}
        onContextMenu={(e) => e.preventDefault()}
        style={{ touchAction: 'none' }}
      />

      {/* 2. HUD PRINCIPAL DO JOGO */}
      {activeModal !== 'start' && (
        <GameHUD
          stats={stats}
          currentDistrict={currentDistrict}
          timeString={timeString}
          timeOfDay={timeOfDay}
          currentWeather={currentWeather}
          isDriving={isDriving}
          nearInteractable={nearInteractable}
          onOpenIdentity={() => setActiveModal('identity')}
          onOpenAtm={() => setActiveModal('atm')}
          onOpenMap={() => setActiveModal('map')}
          onOpenSettings={() => setActiveModal('settings')}
          onOpenKiosk={(title) => {
            if (title) setKioskTitle(title);
            setActiveModal('food');
          }}
          onOpenVehicle={() => setActiveModal('vehicle')}
          onInteract={triggerInteraction}
          onSetWeather={handleSetWeather}
          onSetTimeOfDay={handleSetTimeOfDay}
          onToggleDrive={handleToggleDrive}
          isTouchDevice={isTouchDevice}
          onTouchAction={handleTouchAction}
        />
      )}

      {/* 3. ECRÃ INICIAL DE ENTRADA */}
      {activeModal === 'start' && (
        <StartScreen
          playerName={`${stats.name} ${stats.surname}`}
          idNumber={stats.idNumber}
          onStartGame={() => {
            soundFx.playCandongueiroHorn();
            setActiveModal(null);
          }}
          onOpenIdentity={() => setActiveModal('identity')}
          onOpenSettings={() => setActiveModal('settings')}
        />
      )}

      {/* 4. MODAL DE REGISTO E IDENTIDADE (COM PREVIEW IMEDIATO DAS CALÇAS E ROUPAS) */}
      {activeModal === 'identity' && (
        <IdentityModal
          stats={stats}
          customization={customization}
          onSave={handleSaveIdentity}
          onLiveUpdate={handleLiveCustomization}
          onClose={() => setActiveModal(null)}
        />
      )}

      {/* 5. MODAL MULTICAIXA BFA */}
      {activeModal === 'atm' && (
        <AtmModal
          stats={stats}
          onUpdateStats={setStats}
          onClose={() => setActiveModal(null)}
        />
      )}

      {/* 6. MODAL DE GASTRONOMIA ANGOLANA */}
      {activeModal === 'food' && (
        <FoodModal
          stats={stats}
          onUpdateStats={setStats}
          onClose={() => setActiveModal(null)}
          kioskTitle={kioskTitle}
        />
      )}

      {/* 7. MODAL DE CANDONGUEIRO */}
      {activeModal === 'vehicle' && (
        <VehicleModal
          stats={stats}
          onUpdateStats={setStats}
          onTeleport={handleTeleport}
          onClose={() => setActiveModal(null)}
        />
      )}

      {/* 8. MODAL DE MAPA DE LUANDA */}
      {activeModal === 'map' && (
        <MapModal
          districts={[
            { id: 'centro', name: 'Centro & Baixa', fullName: 'Centro de Luanda & Marginal', description: 'Coração financeiro e histórico de Luanda. Bancos, arranha-céus e obelisco nacional.', center: [50, -10], color: '#3b82f6' },
            { id: 'ilha', name: 'Ilha de Luanda', fullName: 'Ilha do Cabo & Orla Marítima', description: 'Praias de areia dourada, calçadão icónico, coqueiros e quiosques de Mufete.', center: [-35, 0], color: '#06b6d4' },
            { id: 'maianga', name: 'Maianga', fullName: 'Distrito Urbano da Maianga', description: 'Hospital Josina Machel, Esquadra da Polícia Nacional e bairros tradicionais.', center: [35, 35], color: '#8b5cf6' },
            { id: 'viana', name: 'Viana', fullName: 'Município de Viana & Mercados', description: 'Pólo comercial vibrante, mercado dos Congolenses e paragem de candongueiros.', center: [130, -35], color: '#f59e0b' },
            { id: 'talatona', name: 'Talatona', fullName: 'Distrito de Talatona', description: 'Avenidas modernas, postos Sonangol e centros empresariais.', center: [100, 60], color: '#10b981' },
            { id: 'kilamba', name: 'Centralidade do Kilamba', fullName: 'Cidade do Kilamba', description: 'Expansão urbana planejada com blocos residenciais contemporâneos.', center: [80, 120], color: '#ec4899' },
            { id: 'cacuaco', name: 'Cacuaco', fullName: 'Município de Cacuaco', description: 'Zona de pesca e acesso rodoviário ao norte de Luanda.', center: [80, -120], color: '#6366f1' },
          ]}
          interactables={engineRef.current ? engineRef.current.getInteractables() : []}
          playerPos={{
            x: engineRef.current ? engineRef.current.player.position.x : 0,
            z: engineRef.current ? engineRef.current.player.position.z : 0,
          }}
          currentDistrict={currentDistrict}
          onTeleport={handleTeleport}
          onClose={() => setActiveModal(null)}
        />
      )}

      {/* 9. MODAL DE DEFINIÇÕES */}
      {activeModal === 'settings' && (
        <SettingsModal
          settings={settings}
          timeOfDay={timeOfDay}
          onUpdateSettings={handleUpdateSettings}
          onSetTimeOfDay={handleSetTimeOfDay}
          onClose={() => setActiveModal(null)}
        />
      )}
    </div>
  );
}
