/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Play, User, Settings, MapPin, Compass, Shield } from 'lucide-react';
import { soundFx } from '../../game/audio/soundFx';

interface Props {
  playerName: string;
  idNumber: string;
  onStartGame: () => void;
  onOpenIdentity: () => void;
  onOpenSettings: () => void;
}

export const StartScreen: React.FC<Props> = ({
  playerName,
  idNumber,
  onStartGame,
  onOpenIdentity,
  onOpenSettings,
}) => {
  const handleStart = () => {
    soundFx.playCandongueiroHorn();
    onStartGame();
  };

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-gradient-to-b from-black/90 via-zinc-950/95 to-black text-white select-none">
      <div className="relative w-full max-w-xl text-center space-y-6">
        {/* Bandeira & Emblema de Angola */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-red-950/40 border border-amber-500/40 text-xs font-semibold text-amber-400">
          <span>REPÚBLICA DE ANGOLA</span>
          <span>🇦🇴</span>
          <span className="text-zinc-500">•</span>
          <span>CIDADE DE LUANDA</span>
        </div>

        {/* Logótipo Original LUANDA RP */}
        <div className="space-y-2">
          <h1 className="text-5xl md:text-6xl font-black tracking-tighter uppercase drop-shadow-2xl">
            <span className="text-white">LUANDA</span>
            <span className="text-amber-400 ml-2">RP</span>
          </h1>
          <p className="text-sm md:text-base text-zinc-300 font-medium max-w-md mx-auto leading-relaxed">
            Mundo Aberto 3D • Simulação de Vida & Roleplay Angolano
          </p>
          <div className="flex items-center justify-center gap-2 text-xs text-zinc-400">
            <span>Marginal 4 de Fevereiro</span>
            <span>•</span>
            <span>Ilha de Luanda</span>
            <span>•</span>
            <span>Viana</span>
            <span>•</span>
            <span>Talatona</span>
          </div>
        </div>

        {/* Cartão de Apresentação do Cidadão Atual */}
        <div className="p-4 bg-zinc-900/90 border border-zinc-700/80 rounded-2xl max-w-md mx-auto flex items-center justify-between text-left shadow-xl">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <User size={24} />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider">Cidadão Registado</span>
              <div className="text-sm font-bold text-white">{playerName}</div>
              <div className="text-[11px] text-zinc-400 font-mono">BI: {idNumber}</div>
            </div>
          </div>
          <button
            onClick={onOpenIdentity}
            className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-amber-400 rounded-lg border border-zinc-700 transition"
          >
            Editar
          </button>
        </div>

        {/* Botões Principais */}
        <div className="space-y-3 max-w-md mx-auto pt-2">
          <button
            onClick={handleStart}
            className="w-full py-4 px-6 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:brightness-110 active:scale-98 text-zinc-950 font-black text-base uppercase tracking-wider rounded-2xl shadow-2xl transition flex items-center justify-center gap-3 border border-amber-300"
          >
            <Play size={22} className="fill-zinc-950" />
            <span>Entrar em Luanda (Jogar Agora)</span>
          </button>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={onOpenIdentity}
              className="py-3 px-4 bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-700 hover:border-amber-500 rounded-xl text-xs font-bold text-zinc-200 transition flex items-center justify-center gap-2"
            >
              <User size={16} className="text-amber-400" />
              <span>Personalizar Cidadão</span>
            </button>
            <button
              onClick={onOpenSettings}
              className="py-3 px-4 bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-700 hover:border-amber-500 rounded-xl text-xs font-bold text-zinc-200 transition flex items-center justify-center gap-2"
            >
              <Settings size={16} className="text-zinc-400" />
              <span>Definições</span>
            </button>
          </div>
        </div>

        {/* Rodapé e Compatibilidade */}
        <div className="pt-4 border-t border-zinc-800/80 text-xs text-zinc-500 flex items-center justify-center gap-4">
          <span>PC: Teclado + Rato</span>
          <span>•</span>
          <span>Android: Touch + Joystick</span>
          <span>•</span>
          <span>Fase 1: Protótipo Jogável</span>
        </div>
      </div>
    </div>
  );
};
