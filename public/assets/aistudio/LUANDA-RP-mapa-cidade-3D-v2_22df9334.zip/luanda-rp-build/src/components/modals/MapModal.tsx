/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { District, InteractableObject } from '../../game/types';
import { MapPin, Navigation, Compass, X } from 'lucide-react';
import { soundFx } from '../../game/audio/soundFx';

interface Props {
  districts: District[];
  interactables: InteractableObject[];
  playerPos: { x: number; z: number };
  currentDistrict: string;
  onTeleport: (x: number, z: number, name: string) => void;
  onClose: () => void;
}

export const MapModal: React.FC<Props> = ({
  districts,
  interactables,
  playerPos,
  currentDistrict,
  onTeleport,
  onClose,
}) => {
  const handleJump = (d: District) => {
    soundFx.playCandongueiroHorn();
    onTeleport(d.center[0], d.center[1], d.name);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75">
      <div className="relative w-full max-w-2xl bg-zinc-900 border border-zinc-700 rounded-2xl shadow-2xl p-6 text-white max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-500/20 text-blue-400 rounded-lg">
              <Compass size={22} />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">Mapa Oficial de Luanda 🇦🇴</h2>
              <p className="text-xs text-zinc-400">Guia de Exploração Urbana & Distritos de Roleplay</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Informação do Local Atual */}
        <div className="flex items-center justify-between my-4 p-3 bg-zinc-800/80 rounded-xl border border-zinc-700">
          <div className="flex items-center gap-2">
            <MapPin size={18} className="text-red-500" />
            <span className="text-xs text-zinc-300">Localização Atual:</span>
            <span className="text-xs font-bold text-amber-400">{currentDistrict}</span>
          </div>
          <span className="text-[11px] font-mono text-zinc-400">
            X: {Math.round(playerPos.x)} | Z: {Math.round(playerPos.z)}
          </span>
        </div>

        {/* Lista de Distritos de Luanda */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 my-4">
          {districts.map((d) => (
            <div
              key={d.id}
              className={`p-3.5 rounded-xl border transition ${
                currentDistrict === d.name
                  ? 'bg-amber-500/10 border-amber-500/60'
                  : 'bg-zinc-800/50 hover:bg-zinc-800 border-zinc-700/60'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full inline-block"
                    style={{ backgroundColor: d.color }}
                  />
                  {d.name}
                </h3>
                {currentDistrict === d.name && (
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded">
                    Aqui
                  </span>
                )}
              </div>
              <p className="text-xs text-zinc-400 leading-relaxed mb-3">{d.description}</p>

              <button
                onClick={() => handleJump(d)}
                className="w-full flex items-center justify-center gap-1.5 py-1.5 bg-zinc-700 hover:bg-amber-500 hover:text-zinc-950 text-zinc-200 text-xs font-semibold rounded-lg transition"
              >
                <Navigation size={13} />
                Deslocar até {d.name}
              </button>
            </div>
          ))}
        </div>

        {/* Pontos de Interesse Interativos Ativos */}
        <div className="mt-4 pt-4 border-t border-zinc-800">
          <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400 block mb-2">
            Marcos & Pontos Interativos Atuais no Mapa
          </span>
          <div className="flex flex-wrap gap-2">
            {interactables.map((item) => (
              <span
                key={item.id}
                className="px-2.5 py-1 rounded-lg bg-zinc-800 text-[11px] text-zinc-300 border border-zinc-700 flex items-center gap-1.5"
              >
                <span>{item.title}</span>
              </span>
            ))}
          </div>
        </div>

        <div className="flex justify-end pt-4 mt-4 border-t border-zinc-800">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg transition"
          >
            Fechar Mapa
          </button>
        </div>
      </div>
    </div>
  );
};
