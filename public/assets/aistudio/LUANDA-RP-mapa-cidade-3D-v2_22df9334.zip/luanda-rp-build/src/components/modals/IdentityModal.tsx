/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PlayerCustomization, PlayerStats } from '../../game/types';
import { User, Check, X, Sparkles } from 'lucide-react';
import { soundFx } from '../../game/audio/soundFx';

interface Props {
  stats: PlayerStats;
  customization: PlayerCustomization;
  onSave: (stats: PlayerStats, customization: PlayerCustomization) => void;
  onLiveUpdate?: (customization: PlayerCustomization) => void;
  onClose: () => void;
}

export const IdentityModal: React.FC<Props> = ({
  stats,
  customization,
  onSave,
  onLiveUpdate,
  onClose,
}) => {
  const [name, setName] = useState(stats.name);
  const [surname, setSurname] = useState(stats.surname);
  const [skinTone, setSkinTone] = useState(customization.skinTone);
  const [shirtColor, setShirtColor] = useState(customization.shirtColor);
  const [pantsColor, setPantsColor] = useState(customization.pantsColor);
  const [shoesColor, setShoesColor] = useState(customization.shoesColor);

  const skinPalette = [
    { label: 'Ébano Profundo', color: '#2b1810' },
    { label: 'Mogno Africano', color: '#3d2314' },
    { label: 'Castanho Luanda', color: '#4a2c17' },
    { label: 'Cobre Quente', color: '#6b3f20' },
    { label: 'Âmbar Dourado', color: '#8d5524' },
    { label: 'Caramelo Suave', color: '#c68642' },
  ];

  const pantsPalette = [
    { label: 'Azul Ganga (Jeans)', color: '#1e3a8a' },
    { label: 'Preto Urbano', color: '#09090b' },
    { label: 'Bege / Cáqui Chino', color: '#d97706' },
    { label: 'Cinza Escuro', color: '#334155' },
    { label: 'Vermelho Luanda', color: '#dc2626' },
    { label: 'Verde Militar', color: '#16a34a' },
    { label: 'Branco Marginal', color: '#ffffff' },
    { label: 'Azul Celeste', color: '#0284c7' },
  ];

  const shirtPalette = [
    { label: 'Vermelho Patriota', color: '#dc2626' },
    { label: 'Azul Candongueiro', color: '#1d4ed8' },
    { label: 'Amarelo Ouro', color: '#eab308' },
    { label: 'Verde Esperança', color: '#16a34a' },
    { label: 'Preto Clássico', color: '#0f172a' },
    { label: 'Branco Elegante', color: '#ffffff' },
    { label: 'Roxo Estiloso', color: '#9333ea' },
    { label: 'Laranja Tropical', color: '#ea580c' },
  ];

  const shoesPalette = [
    { label: 'Ténis Branco', color: '#ffffff' },
    { label: 'Sapatos Pretos', color: '#09090b' },
    { label: 'Sapatilhas Vermelhas', color: '#dc2626' },
    { label: 'Botas Castanhas', color: '#78350f' },
    { label: 'Ténis Azuis', color: '#1d4ed8' },
  ];

  const updatePants = (color: string) => {
    setPantsColor(color);
    soundFx.playInteract();
    if (onLiveUpdate) {
      onLiveUpdate({
        ...customization,
        skinTone,
        shirtColor,
        pantsColor: color,
        shoesColor,
      });
    }
  };

  const updateShirt = (color: string) => {
    setShirtColor(color);
    soundFx.playInteract();
    if (onLiveUpdate) {
      onLiveUpdate({
        ...customization,
        skinTone,
        shirtColor: color,
        pantsColor,
        shoesColor,
      });
    }
  };

  const updateSkin = (color: string) => {
    setSkinTone(color);
    soundFx.playInteract();
    if (onLiveUpdate) {
      onLiveUpdate({
        ...customization,
        skinTone: color,
        shirtColor,
        pantsColor,
        shoesColor,
      });
    }
  };

  const updateShoes = (color: string) => {
    setShoesColor(color);
    soundFx.playInteract();
    if (onLiveUpdate) {
      onLiveUpdate({
        ...customization,
        skinTone,
        shirtColor,
        pantsColor,
        shoesColor: color,
      });
    }
  };

  const handleSave = () => {
    soundFx.playInteract();
    onSave(
      {
        ...stats,
        name: name.trim() || 'Mauro',
        surname: surname.trim() || 'dos Santos',
      },
      {
        ...customization,
        skinTone,
        shirtColor,
        pantsColor,
        shoesColor,
      }
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80">
      <div className="relative w-full max-w-lg bg-zinc-900 border-2 border-amber-500/60 rounded-2xl shadow-2xl p-6 text-white max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/30">
              <User size={24} />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
                Personalização do Cidadão
                <span className="text-xs bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded-full font-normal">
                  Luanda RP 🇦🇴
                </span>
              </h2>
              <p className="text-xs text-zinc-400">República de Angola • Visual e Bilhete de Identidade</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Cartão de Bilhete de Identidade Angolano Fictício */}
        <div className="my-4 p-4 rounded-xl bg-gradient-to-r from-red-950/60 via-zinc-900 to-black border border-amber-500/40 shadow-inner">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-black uppercase tracking-wider text-amber-400">
              REPÚBLICA DE ANGOLA 🇦🇴
            </span>
            <span className="text-[11px] font-mono text-zinc-400">BI: {stats.idNumber}</span>
          </div>
          <div className="text-lg font-black text-white">{name || 'Mauro'} {surname || 'dos Santos'}</div>
          <div className="flex items-center gap-2 text-xs text-zinc-400 mt-1">
            <span>Naturalidade: Luanda</span>
            <span>•</span>
            <span className="text-emerald-400 font-semibold">Cidadão Ativo</span>
          </div>
        </div>

        <div className="space-y-5">
          {/* Nomes */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Primeiro Nome</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-sm text-white focus:outline-none focus:border-amber-500"
                placeholder="Ex: Mauro"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Apelido (Sobrenome)</label>
              <input
                type="text"
                value={surname}
                onChange={(e) => setSurname(e.target.value)}
                className="w-full px-3 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-sm text-white focus:outline-none focus:border-amber-500"
                placeholder="Ex: dos Santos"
              />
            </div>
          </div>

          {/* COR DAS CALÇAS (DESTAQUE PARA O UTILIZADOR) */}
          <div className="p-3.5 bg-zinc-800/60 rounded-xl border border-zinc-700/80">
            <div className="flex items-center justify-between mb-2.5">
              <label className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles size={14} />
                Cor das Calças / Jeans
              </label>
              <span className="text-xs text-zinc-300 font-medium">
                {pantsPalette.find((p) => p.color === pantsColor)?.label || 'Personalizado'}
              </span>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {pantsPalette.map((item) => (
                <button
                  type="button"
                  key={item.color}
                  onClick={() => updatePants(item.color)}
                  style={{ backgroundColor: item.color }}
                  className={`h-11 rounded-xl flex items-center justify-center transition border-2 shadow-sm ${
                    pantsColor === item.color
                      ? 'border-amber-400 scale-105 ring-2 ring-amber-400/50'
                      : 'border-zinc-700 hover:border-zinc-500'
                  }`}
                  title={item.label}
                >
                  {pantsColor === item.color && (
                    <Check
                      size={18}
                      className={item.color === '#ffffff' ? 'text-black font-black' : 'text-white font-black'}
                    />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* COR DA CAMISA / POLO */}
          <div className="p-3.5 bg-zinc-800/60 rounded-xl border border-zinc-700/80">
            <div className="flex items-center justify-between mb-2.5">
              <label className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
                Cor da Camisa / Roupa
              </label>
              <span className="text-xs text-zinc-400 font-medium">
                {shirtPalette.find((s) => s.color === shirtColor)?.label || 'Personalizado'}
              </span>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {shirtPalette.map((item) => (
                <button
                  type="button"
                  key={item.color}
                  onClick={() => updateShirt(item.color)}
                  style={{ backgroundColor: item.color }}
                  className={`h-11 rounded-xl flex items-center justify-center transition border-2 shadow-sm ${
                    shirtColor === item.color
                      ? 'border-amber-400 scale-105 ring-2 ring-amber-400/50'
                      : 'border-zinc-700 hover:border-zinc-500'
                  }`}
                  title={item.label}
                >
                  {shirtColor === item.color && (
                    <Check
                      size={18}
                      className={item.color === '#ffffff' ? 'text-black font-black' : 'text-white font-black'}
                    />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* TOM DE PELE */}
          <div className="p-3.5 bg-zinc-800/60 rounded-xl border border-zinc-700/80">
            <div className="flex items-center justify-between mb-2.5">
              <label className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
                Tom de Pele
              </label>
              <span className="text-xs text-zinc-400 font-medium">
                {skinPalette.find((s) => s.color === skinTone)?.label || 'Personalizado'}
              </span>
            </div>
            <div className="grid grid-cols-6 gap-2">
              {skinPalette.map((item) => (
                <button
                  type="button"
                  key={item.color}
                  onClick={() => updateSkin(item.color)}
                  style={{ backgroundColor: item.color }}
                  className={`h-10 rounded-full flex items-center justify-center transition border-2 shadow-sm ${
                    skinTone === item.color
                      ? 'border-amber-400 scale-110 ring-2 ring-amber-400/50'
                      : 'border-zinc-700 hover:border-zinc-500'
                  }`}
                  title={item.label}
                >
                  {skinTone === item.color && <Check size={16} className="text-white font-black" />}
                </button>
              ))}
            </div>
          </div>

          {/* COR DO CALÇADO */}
          <div className="p-3.5 bg-zinc-800/60 rounded-xl border border-zinc-700/80">
            <div className="flex items-center justify-between mb-2.5">
              <label className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
                Calçado / Ténis
              </label>
              <span className="text-xs text-zinc-400 font-medium">
                {shoesPalette.find((s) => s.color === shoesColor)?.label || 'Personalizado'}
              </span>
            </div>
            <div className="grid grid-cols-5 gap-2">
              {shoesPalette.map((item) => (
                <button
                  type="button"
                  key={item.color}
                  onClick={() => updateShoes(item.color)}
                  style={{ backgroundColor: item.color }}
                  className={`h-10 rounded-xl flex items-center justify-center transition border-2 shadow-sm ${
                    shoesColor === item.color
                      ? 'border-amber-400 scale-105 ring-2 ring-amber-400/50'
                      : 'border-zinc-700 hover:border-zinc-500'
                  }`}
                  title={item.label}
                >
                  {shoesColor === item.color && (
                    <Check
                      size={16}
                      className={item.color === '#ffffff' ? 'text-black font-black' : 'text-white font-black'}
                    />
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 mt-6 pt-4 border-t border-zinc-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 text-sm text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 transition"
          >
            Fechar
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="flex items-center gap-2 px-6 py-2.5 text-sm font-bold text-zinc-950 bg-amber-500 hover:bg-amber-400 rounded-xl transition shadow-xl border border-amber-300"
          >
            <Check size={18} />
            Guardar Cidadão
          </button>
        </div>
      </div>
    </div>
  );
};
