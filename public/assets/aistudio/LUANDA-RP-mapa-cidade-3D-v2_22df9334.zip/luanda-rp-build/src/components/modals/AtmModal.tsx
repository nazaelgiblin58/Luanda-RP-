/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PlayerStats } from '../../game/types';
import { CreditCard, ArrowDownRight, ArrowUpRight, CheckCircle2, AlertCircle, X } from 'lucide-react';
import { soundFx } from '../../game/audio/soundFx';

interface Props {
  stats: PlayerStats;
  onUpdateStats: (newStats: PlayerStats) => void;
  onClose: () => void;
}

export const AtmModal: React.FC<Props> = ({ stats, onUpdateStats, onClose }) => {
  const [feedback, setFeedback] = useState<string | null>(null);

  const formatKz = (val: number) => {
    return new Intl.NumberFormat('pt-AO', {
      style: 'currency',
      currency: 'AOA',
      maximumFractionDigits: 0,
    }).format(val).replace('AOA', 'Kz');
  };

  const handleWithdraw = (amount: number) => {
    if (stats.bankKz < amount) {
      setFeedback('Saldo bancário insuficiente para esta operação!');
      return;
    }
    soundFx.playAtmCash();
    onUpdateStats({
      ...stats,
      bankKz: stats.bankKz - amount,
      cashKz: stats.cashKz + amount,
    });
    setFeedback(`Levantamento de ${formatKz(amount)} efetuado com sucesso!`);
  };

  const handleDeposit = (amount: number) => {
    if (stats.cashKz < amount) {
      setFeedback('Dinheiro em carteira insuficiente!');
      return;
    }
    soundFx.playAtmCash();
    onUpdateStats({
      ...stats,
      cashKz: stats.cashKz - amount,
      bankKz: stats.bankKz + amount,
    });
    setFeedback(`Depósito de ${formatKz(amount)} creditado na conta!`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75">
      <div className="relative w-full max-w-md bg-zinc-900 border-2 border-emerald-500/50 rounded-2xl shadow-2xl p-6 text-white overflow-hidden">
        {/* Cabeçalho Multicaixa */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg">
              <CreditCard size={24} />
            </div>
            <div>
              <h2 className="text-lg font-bold tracking-tight text-emerald-400">MULTICAIXA • REDE EMIS</h2>
              <p className="text-xs text-zinc-400">Banco de Fomento Angola (BFA) • Luanda</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Resumo de Saldos */}
        <div className="grid grid-cols-2 gap-3 my-5">
          <div className="p-3 bg-zinc-800/80 rounded-xl border border-zinc-700">
            <span className="text-[11px] font-medium text-zinc-400 uppercase tracking-wider block mb-1">
              Carteira (Físico)
            </span>
            <span className="text-base font-bold text-amber-400">{formatKz(stats.cashKz)}</span>
          </div>
          <div className="p-3 bg-emerald-950/40 rounded-xl border border-emerald-500/30">
            <span className="text-[11px] font-medium text-emerald-300 uppercase tracking-wider block mb-1">
              Conta Bancária
            </span>
            <span className="text-base font-bold text-emerald-400">{formatKz(stats.bankKz)}</span>
          </div>
        </div>

        {feedback && (
          <div className="mb-4 p-2.5 rounded-lg bg-zinc-800 border border-zinc-700 text-xs flex items-center gap-2 text-zinc-200">
            <AlertCircle size={15} className="text-amber-400 shrink-0" />
            <span>{feedback}</span>
          </div>
        )}

        {/* Operações de Levantamento */}
        <div className="space-y-3">
          <span className="text-xs font-semibold text-zinc-300 uppercase tracking-wider block">
            Levantamento Rápido (Saque)
          </span>
          <div className="grid grid-cols-2 gap-2">
            {[2000, 5000, 10000, 25000].map((amt) => (
              <button
                key={`w-${amt}`}
                onClick={() => handleWithdraw(amt)}
                className="flex items-center justify-between px-3 py-2.5 bg-zinc-800 hover:bg-emerald-600/30 border border-zinc-700 hover:border-emerald-500 rounded-lg text-sm font-medium transition"
              >
                <span>{formatKz(amt)}</span>
                <ArrowDownRight size={16} className="text-emerald-400" />
              </button>
            ))}
          </div>
        </div>

        {/* Operações de Depósito */}
        <div className="space-y-3 mt-4">
          <span className="text-xs font-semibold text-zinc-300 uppercase tracking-wider block">
            Depósito na Conta
          </span>
          <div className="grid grid-cols-2 gap-2">
            {[5000, 20000].map((amt) => (
              <button
                key={`d-${amt}`}
                onClick={() => handleDeposit(amt)}
                className="flex items-center justify-between px-3 py-2.5 bg-zinc-800 hover:bg-amber-600/30 border border-zinc-700 hover:border-amber-500 rounded-lg text-sm font-medium transition"
              >
                <span>{formatKz(amt)}</span>
                <ArrowUpRight size={16} className="text-amber-400" />
              </button>
            ))}
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg transition"
          >
            Retirar Cartão Multicaixa
          </button>
        </div>
      </div>
    </div>
  );
};
