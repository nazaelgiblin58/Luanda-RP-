/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { GameSettings } from '../../game/types';
import { Settings, Monitor, Volume2, Clock, X, ShieldCheck } from 'lucide-react';
import { soundFx } from '../../game/audio/soundFx';

interface Props {
  settings: GameSettings;
  timeOfDay: number;
  onUpdateSettings: (newSettings: GameSettings) => void;
  onSetTimeOfDay: (hour: number) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<Props> = ({
  settings,
  timeOfDay,
  onUpdateSettings,
  onSetTimeOfDay,
  onClose,
}) => {
  const handleQualityChange = (q: 'low' | 'medium' | 'high') => {
    soundFx.playInteract();
    onUpdateSettings({
      ...settings,
      graphicsQuality: q,
      shadows: q !== 'low',
    });
  };

  const handleVolumeChange = (vol: number) => {
    soundFx.setVolume(vol);
    onUpdateSettings({
      ...settings,
      soundVolume: vol,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75">
      <div className="relative w-full max-w-md bg-zinc-900 border border-zinc-700 rounded-2xl shadow-2xl p-6 text-white max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-zinc-800 text-amber-400 rounded-lg">
              <Settings size={22} />
            </div>
            <div>
              <h2 className="text-lg font-bold tracking-tight">Definições do Jogo</h2>
              <p className="text-xs text-zinc-400">LUANDA RP 🇦🇴 • Ajustes de Sistema</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        <div className="space-y-5 my-5">
          {/* Qualidade Gráfica */}
          <div>
            <label className="flex items-center gap-2 text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2">
              <Monitor size={15} className="text-amber-400" />
              Desempenho Gráfico
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['low', 'medium', 'high'] as const).map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => handleQualityChange(lvl)}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold uppercase tracking-wider border transition ${
                    settings.graphicsQuality === lvl
                      ? 'bg-amber-500 text-zinc-950 border-amber-400'
                      : 'bg-zinc-800 text-zinc-300 border-zinc-700 hover:bg-zinc-700'
                  }`}
                >
                  {lvl === 'low' ? 'Baixa' : lvl === 'medium' ? 'Média' : 'Alta'}
                </button>
              ))}
            </div>
            <p className="text-[11px] text-zinc-400 mt-1">
              Otimizado para PC de 4 GB RAM, notebooks e telemóveis Android.
            </p>
          </div>

          {/* Volume de Som */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="flex items-center gap-2 text-xs font-semibold text-zinc-300 uppercase tracking-wider">
                <Volume2 size={15} className="text-amber-400" />
                Volume de Efeitos e Áudio
              </label>
              <span className="text-xs text-amber-400 font-mono">{Math.round(settings.soundVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={settings.soundVolume}
              onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
              className="w-full accent-amber-500 bg-zinc-800"
            />
          </div>

          {/* Clima de Luanda */}
          <div>
            <label className="flex items-center gap-2 text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2">
              <Clock size={15} className="text-amber-400" />
              Clima Atmosférico de Luanda
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: '☀️ Ensolarado Tropical', val: 'ensolarado' },
                { label: '🌫️ Cacimbo de Luanda', val: 'cacimbo' },
                { label: '🌧️ Chuva Tropical', val: 'chuva' },
                { label: '🌅 Pôr-do-Sol Dourado', val: 'pordosol' },
                { label: '🌙 Noite Urbana', val: 'noite' },
              ].map((w) => (
                <button
                  type="button"
                  key={w.val}
                  onClick={() => {
                    soundFx.playInteract();
                    onUpdateSettings({ ...settings, weather: w.val as any });
                  }}
                  className={`py-2 px-2.5 rounded-lg text-xs font-medium border transition text-left ${
                    settings.weather === w.val
                      ? 'bg-amber-500 text-zinc-950 font-bold border-amber-400'
                      : 'bg-zinc-800 text-zinc-200 border-zinc-700 hover:bg-zinc-700'
                  }`}
                >
                  {w.label}
                </button>
              ))}
            </div>
          </div>

          {/* Horário / Ambiente de Luanda */}
          <div>
            <label className="flex items-center gap-2 text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2">
              <Clock size={15} className="text-amber-400" />
              Ciclo Horário de Luanda
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: 'Manhã (09h)', hour: 9 },
                { label: 'Tarde (16h)', hour: 16 },
                { label: 'Noite (21h)', hour: 21 },
              ].map((preset) => (
                <button
                  type="button"
                  key={preset.hour}
                  onClick={() => {
                    soundFx.playInteract();
                    onSetTimeOfDay(preset.hour);
                  }}
                  className="py-2 px-2 rounded-lg text-xs font-medium bg-zinc-800 border border-zinc-700 hover:border-amber-500 text-zinc-200 transition"
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          {/* Informações do Sistema */}
          <div className="p-3 bg-zinc-800/60 rounded-xl border border-zinc-700/60 text-xs text-zinc-300 space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-emerald-400">
              <ShieldCheck size={16} />
              <span>LUANDA RP — SISTEMA ESTÁVEL</span>
            </div>
            <p className="text-[11px] text-zinc-400">
              Three.js r160+ otimizado a 60 FPS, Tráfego Automático, Chuva & Cacimbo, Árvores Dinâmicas e Condução.
            </p>
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t border-zinc-800">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium bg-amber-500 text-zinc-950 font-bold rounded-lg hover:bg-amber-400 transition"
          >
            Fechar Definições
          </button>
        </div>
      </div>
    </div>
  );
};
