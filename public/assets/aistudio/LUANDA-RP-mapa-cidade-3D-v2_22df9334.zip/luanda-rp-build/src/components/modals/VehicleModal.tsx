/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PlayerStats } from '../../game/types';
import { Radio, Volume2, Navigation, AlertCircle, X } from 'lucide-react';
import { soundFx } from '../../game/audio/soundFx';

interface Props {
  stats: PlayerStats;
  onUpdateStats: (newStats: PlayerStats) => void;
  onTeleport: (x: number, z: number, districtName: string) => void;
  onClose: () => void;
}

export const VehicleModal: React.FC<Props> = ({ stats, onUpdateStats, onTeleport, onClose }) => {
  const [radioActive, setRadioActive] = useState(soundFx.getRadioPlaying());
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleHorn = () => {
    soundFx.playCandongueiroHorn();
    setFeedback('Buzinaste: "Bii-Bii! Mutamba, Viana, entra com calma!"');
  };

  const handleToggleRadio = () => {
    const isPlaying = soundFx.toggleRadio();
    setRadioActive(isPlaying);
    setFeedback(isPlaying ? 'Rádio Luanda FM sintonizada (Kizomba/Semba)' : 'Rádio desligada.');
  };

  const handleRide = (destName: string, x: number, z: number, fare: number) => {
    if (stats.cashKz < fare) {
      setFeedback('Sem dinheiro suficiente para pagar a corrida do candongueiro!');
      return;
    }

    soundFx.playCandongueiroHorn();
    onUpdateStats({
      ...stats,
      cashKz: stats.cashKz - fare,
    });
    onTeleport(x, z, destName);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75">
      <div className="relative w-full max-w-lg bg-zinc-900 border-2 border-blue-500/50 rounded-2xl shadow-2xl p-6 text-white overflow-hidden">
        {/* Banner do Candongueiro Azul e Branco */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-b from-white via-blue-600 to-blue-700 flex items-center justify-center text-xl shadow-md border border-blue-400">
              🚐
            </div>
            <div>
              <h2 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
                Candongueiro Azul e Branco
                <span className="text-xs px-2 py-0.5 rounded bg-blue-600/30 text-blue-300 font-mono">LD-24-94-RP</span>
              </h2>
              <p className="text-xs text-zinc-400">Táxi Coletivo Popular de Luanda • Linhas Expressas</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {feedback && (
          <div className="mt-4 p-2.5 rounded-lg bg-blue-950/40 border border-blue-600/40 text-xs flex items-center gap-2 text-blue-200">
            <AlertCircle size={15} className="text-blue-400 shrink-0" />
            <span>{feedback}</span>
          </div>
        )}

        {/* Painel do Condutor / Ações */}
        <div className="grid grid-cols-2 gap-3 my-5">
          <button
            onClick={handleHorn}
            className="flex items-center justify-center gap-2 p-3 bg-zinc-800 hover:bg-blue-600/30 border border-zinc-700 hover:border-blue-500 rounded-xl text-sm font-semibold transition"
          >
            <Volume2 size={18} className="text-blue-400" />
            Buzinar Bibi!
          </button>
          <button
            onClick={handleToggleRadio}
            className={`flex items-center justify-center gap-2 p-3 border rounded-xl text-sm font-semibold transition ${
              radioActive
                ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                : 'bg-zinc-800 hover:bg-zinc-700 border-zinc-700 text-zinc-300'
            }`}
          >
            <Radio size={18} className={radioActive ? 'text-amber-400 animate-pulse' : 'text-zinc-400'} />
            {radioActive ? 'Desligar Rádio' : 'Ligar Rádio Luanda'}
          </button>
        </div>

        {/* Linhas e Destinos de Luanda */}
        <div className="space-y-3">
          <span className="text-xs font-semibold text-zinc-300 uppercase tracking-wider block">
            Apanhar Táxi para Outro Distrito (Corrida 200 Kz)
          </span>

          <div className="space-y-2">
            {[
              { name: 'Ilha de Luanda & Marginal', x: -28, z: -40, desc: 'Praia, Calçadão e Esplanadas' },
              { name: 'Centro de Luanda & Mutamba', x: 20, z: -10, desc: 'Bancos, Monumento e Comércio' },
              { name: 'Mercado de Viana & Congolenses', x: 120, z: -30, desc: 'Bancadas Populares e Feira' },
              { name: 'Talatona & Sonangol', x: 100, z: 40, desc: 'Distrito Empresarial e Posto' },
            ].map((route) => (
              <div
                key={route.name}
                className="p-3 bg-zinc-800/60 hover:bg-zinc-800 border border-zinc-700/60 rounded-xl flex items-center justify-between gap-3 transition"
              >
                <div>
                  <h4 className="text-sm font-semibold text-white">{route.name}</h4>
                  <p className="text-xs text-zinc-400">{route.desc}</p>
                </div>
                <button
                  onClick={() => handleRide(route.name, route.x, route.z, 200)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg transition shrink-0"
                >
                  <Navigation size={14} />
                  <span>200 Kz</span>
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg transition"
          >
            Sair do Candongueiro
          </button>
        </div>
      </div>
    </div>
  );
};
