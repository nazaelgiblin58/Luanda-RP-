/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PlayerStats } from '../../game/types';
import { Utensils, Coffee, AlertCircle, Check, X } from 'lucide-react';
import { soundFx } from '../../game/audio/soundFx';

interface Props {
  stats: PlayerStats;
  onUpdateStats: (newStats: PlayerStats) => void;
  onClose: () => void;
  kioskTitle?: string;
}

interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  hungerBoost: number;
  thirstBoost: number;
  energyBoost: number;
  healthBoost: number;
  type: 'food' | 'drink';
}

const MENU_ITEMS: MenuItem[] = [
  {
    id: 'mufete',
    name: 'Mufete de Peixe da Ilha 🐟',
    description: 'Peixe carapau grelhado na brasa, feijão de óleo de palma, farofa e banana-pão.',
    price: 1800,
    hungerBoost: 50,
    thirstBoost: 5,
    energyBoost: 25,
    healthBoost: 15,
    type: 'food',
  },
  {
    id: 'calulu',
    name: 'Calulu de Peixe Seco & Funge 🍲',
    description: 'Prato tradicional com folhas de rama, peixe seco, quiabos e funge de mandioca quente.',
    price: 2200,
    hungerBoost: 60,
    thirstBoost: 0,
    energyBoost: 30,
    healthBoost: 20,
    type: 'food',
  },
  {
    id: 'moamba',
    name: 'Moamba de Galinha de Angola 🍗',
    description: 'Galinha rija cozida lentamente no molho rico de dendém e alho com quiabos frescos.',
    price: 2500,
    hungerBoost: 65,
    thirstBoost: 0,
    energyBoost: 35,
    healthBoost: 25,
    type: 'food',
  },
  {
    id: 'cuca',
    name: 'Cuca bem Gelada (33cl) 🍺',
    description: 'A cerveja mais emblemática e refrescante de Luanda para aliviar o calor.',
    price: 500,
    hungerBoost: 5,
    thirstBoost: 45,
    energyBoost: 15,
    healthBoost: 0,
    type: 'drink',
  },
  {
    id: 'agua',
    name: 'Água Pura da Chela (500ml) 💧',
    description: 'Água mineral límpida e fresca, hidratação instantânea.',
    price: 300,
    hungerBoost: 0,
    thirstBoost: 60,
    energyBoost: 10,
    healthBoost: 10,
    type: 'drink',
  },
  {
    id: 'kisangua',
    name: 'Kisangua Tradicional Caseira 🥤',
    description: 'Bebida fermentada refrescante à base de milho e canela.',
    price: 450,
    hungerBoost: 15,
    thirstBoost: 40,
    energyBoost: 20,
    healthBoost: 5,
    type: 'drink',
  },
];

export const FoodModal: React.FC<Props> = ({ stats, onUpdateStats, onClose, kioskTitle }) => {
  const [feedback, setFeedback] = useState<string | null>(null);

  const formatKz = (val: number) => {
    return new Intl.NumberFormat('pt-AO', {
      style: 'currency',
      currency: 'AOA',
      maximumFractionDigits: 0,
    }).format(val).replace('AOA', 'Kz');
  };

  const handleBuy = (item: MenuItem) => {
    if (stats.cashKz < item.price) {
      setFeedback('Kwanza insuficiente na carteira! Passe no Multicaixa para levantar dinheiro.');
      return;
    }

    soundFx.playInteract();
    onUpdateStats({
      ...stats,
      cashKz: stats.cashKz - item.price,
      hunger: Math.min(100, stats.hunger + item.hungerBoost),
      thirst: Math.min(100, stats.thirst + item.thirstBoost),
      energy: Math.min(100, stats.energy + item.energyBoost),
      health: Math.min(100, stats.health + item.healthBoost),
    });
    setFeedback(`Consumiu ${item.name}! Vitalidade restaurada.`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75">
      <div className="relative w-full max-w-lg bg-zinc-900 border border-amber-600/40 rounded-2xl shadow-2xl p-6 text-white max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-lg">
              <Utensils size={24} />
            </div>
            <div>
              <h2 className="text-lg font-bold tracking-tight text-amber-400">
                {kioskTitle || 'Quiosque de Gastronomia Angolana 🇦🇴'}
              </h2>
              <p className="text-xs text-zinc-400">Sabores Autênticos de Luanda • Ilha & Marginal</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Resumo da Carteira */}
        <div className="flex items-center justify-between my-4 p-3 bg-zinc-800/80 rounded-xl border border-zinc-700">
          <span className="text-xs text-zinc-400 font-medium">Dinheiro Disponível na Carteira:</span>
          <span className="text-sm font-bold text-amber-400">{formatKz(stats.cashKz)}</span>
        </div>

        {feedback && (
          <div className="mb-4 p-2.5 rounded-lg bg-zinc-800 border border-zinc-700 text-xs flex items-center gap-2 text-zinc-200">
            <AlertCircle size={15} className="text-amber-400 shrink-0" />
            <span>{feedback}</span>
          </div>
        )}

        {/* Lista do Cardápio */}
        <div className="space-y-3">
          {MENU_ITEMS.map((item) => (
            <div
              key={item.id}
              className="p-3 bg-zinc-800/50 hover:bg-zinc-800 border border-zinc-700/60 rounded-xl transition flex items-center justify-between gap-3"
            >
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-semibold text-white">{item.name}</h3>
                  <span className="text-xs font-bold text-amber-400 px-2 py-0.5 bg-amber-500/10 rounded">
                    {formatKz(item.price)}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-1 leading-relaxed">{item.description}</p>
                <div className="flex items-center gap-3 text-[11px] text-zinc-400 mt-2">
                  {item.hungerBoost > 0 && <span className="text-emerald-400">+{item.hungerBoost}% Fome</span>}
                  {item.thirstBoost > 0 && <span className="text-cyan-400">+{item.thirstBoost}% Sede</span>}
                  {item.energyBoost > 0 && <span className="text-amber-400">+{item.energyBoost}% Energia</span>}
                </div>
              </div>

              <button
                onClick={() => handleBuy(item)}
                className="px-3 py-2 bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold rounded-lg transition shrink-0"
              >
                Comprar
              </button>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg transition"
          >
            Sair do Quiosque
          </button>
        </div>
      </div>
    </div>
  );
};
