/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { InteractableObject, PlayerStats, WeatherType } from '../../game/types';
import {
  Heart,
  Zap,
  Utensils,
  Droplet,
  MapPin,
  Clock,
  ChevronDown,
  ChevronUp,
  User,
  CreditCard,
  Map,
  Radio,
  Settings,
  HelpCircle,
  CloudRain,
  Sun,
  CloudFog,
  Sunset,
  Moon,
  Car,
  Volume2,
} from 'lucide-react';
import { soundFx } from '../../game/audio/soundFx';

interface Props {
  stats: PlayerStats;
  currentDistrict: string;
  timeString: string;
  timeOfDay: number;
  currentWeather: WeatherType;
  isDriving: boolean;
  nearInteractable: InteractableObject | null;
  onOpenIdentity: () => void;
  onOpenAtm: () => void;
  onOpenMap: () => void;
  onOpenSettings: () => void;
  onOpenKiosk: (kioskTitle?: string) => void;
  onOpenVehicle: () => void;
  onInteract: () => void;
  onSetWeather: (w: WeatherType) => void;
  onSetTimeOfDay: (hour: number) => void;
  onToggleDrive: () => void;
  isTouchDevice: boolean;
  onTouchAction?: (action: 'forward' | 'backward' | 'left' | 'right' | 'sprint' | 'jump' | 'interact' | 'horn') => void;
}

export const GameHUD: React.FC<Props> = ({
  stats,
  currentDistrict,
  timeString,
  timeOfDay,
  currentWeather,
  isDriving,
  nearInteractable,
  onOpenIdentity,
  onOpenAtm,
  onOpenMap,
  onOpenSettings,
  onOpenKiosk,
  onOpenVehicle,
  onInteract,
  onSetWeather,
  onSetTimeOfDay,
  onToggleDrive,
  isTouchDevice,
  onTouchAction,
}) => {
  const [isDockCollapsed, setIsDockCollapsed] = useState(false);
  const [showControlsGuide, setShowControlsGuide] = useState(false);
  const [showEnvironmentPanel, setShowEnvironmentPanel] = useState(false);
  const isRadioOn = soundFx.getRadioPlaying();

  const formatKz = (val: number) => {
    return new Intl.NumberFormat('pt-AO', {
      style: 'currency',
      currency: 'AOA',
      maximumFractionDigits: 0,
    }).format(val).replace('AOA', 'Kz');
  };

  const weatherIcons: Record<WeatherType, React.ReactNode> = {
    ensolarado: <Sun size={14} className="text-amber-400" />,
    cacimbo: <CloudFog size={14} className="text-slate-300" />,
    chuva: <CloudRain size={14} className="text-blue-400" />,
    pordosol: <Sunset size={14} className="text-orange-400" />,
    noite: <Moon size={14} className="text-indigo-300" />,
  };

  const weatherLabels: Record<WeatherType, string> = {
    ensolarado: 'Ensolarado',
    cacimbo: 'Cacimbo',
    chuva: 'Chuva Tropical',
    pordosol: 'Pôr-do-Sol',
    noite: 'Noite Urbana',
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-10 flex flex-col justify-between overflow-hidden">
      {/* 1. BARRA SUPERIOR (TOP-LEFT / TOP-RIGHT) */}
      <header className="w-full p-3.5 flex items-start justify-between pointer-events-auto">
        {/* Top-Left: Badge de Identidade, Bairro e Relógio de Luanda */}
        <div className="bg-zinc-950/95 border border-zinc-800 rounded-2xl p-3.5 shadow-2xl text-white max-w-sm">
          <div className="flex items-center justify-between gap-3 mb-2">
            <div className="flex items-center gap-2">
              <span className="text-sm font-black tracking-wider text-amber-400">LUANDA RP</span>
              <span className="text-xs">🇦🇴</span>
            </div>

            {/* Relógio & Seletor de Clima Interativo */}
            <button
              type="button"
              onClick={() => setShowEnvironmentPanel(!showEnvironmentPanel)}
              className="flex items-center gap-1.5 px-2 py-1 bg-zinc-800/80 hover:bg-zinc-700 border border-zinc-700 rounded-lg text-xs font-mono text-amber-300 transition"
              title="Ajustar Clima e Horas"
            >
              {weatherIcons[currentWeather]}
              <Clock size={12} className="text-amber-400 ml-1" />
              <span>{timeString}</span>
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs font-semibold text-zinc-200">
            <span className="truncate">{stats.name} {stats.surname}</span>
            <span className="text-zinc-600">•</span>
            <span className="text-amber-400 flex items-center gap-1 font-mono">
              <MapPin size={12} className="text-red-400 shrink-0" />
              {currentDistrict}
            </span>
          </div>

          {/* Dinheiro Kwanza (Kz) */}
          <div className="mt-2.5 pt-2 border-t border-zinc-800/80 flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-bold text-zinc-400">Carteira:</span>
              <span className="font-bold text-amber-400 font-mono">{formatKz(stats.cashKz)}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-bold text-zinc-400">Banco:</span>
              <span className="font-bold text-emerald-400 font-mono">{formatKz(stats.bankKz)}</span>
            </div>
          </div>
        </div>

        {/* Top-Right: Guia e Definições */}
        <div className="flex items-center gap-2">
          {/* Se estiver a conduzir, mostra botão de buzina rápida */}
          {isDriving && (
            <button
              type="button"
              onClick={() => soundFx.playCandongueiroHorn()}
              className="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-xl flex items-center gap-1.5 border border-blue-400"
            >
              <Volume2 size={16} />
              <span>Buzinar (H)</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setShowControlsGuide(!showControlsGuide)}
            className="p-2.5 bg-zinc-950/90 border border-zinc-800 hover:border-amber-500 text-zinc-300 hover:text-white rounded-xl shadow-xl transition flex items-center gap-1.5 text-xs font-semibold"
          >
            <HelpCircle size={16} className="text-amber-400" />
            <span className="hidden sm:inline">Teclas</span>
          </button>
          <button
            type="button"
            onClick={onOpenSettings}
            className="p-2.5 bg-zinc-950/90 border border-zinc-800 hover:border-amber-500 text-zinc-300 hover:text-white rounded-xl shadow-xl transition"
            title="Definições"
          >
            <Settings size={18} />
          </button>
        </div>
      </header>

      {/* PAINEL FLUTUANTE DE CLIMA & HORAS */}
      {showEnvironmentPanel && (
        <div className="absolute top-24 left-4 p-4 bg-zinc-950/98 border border-zinc-700 rounded-2xl shadow-2xl text-white pointer-events-auto max-w-sm z-30">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-zinc-800">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Sun size={14} /> Clima & Relógio de Luanda
            </span>
            <button
              type="button"
              onClick={() => setShowEnvironmentPanel(false)}
              className="text-zinc-400 hover:text-white text-xs"
            >
              ✕
            </button>
          </div>

          {/* Seleção de Climas */}
          <div className="space-y-2 mb-4">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">
              Escolher Clima de Luanda:
            </span>
            <div className="grid grid-cols-2 gap-2">
              {(['ensolarado', 'cacimbo', 'chuva', 'pordosol', 'noite'] as WeatherType[]).map((w) => (
                <button
                  type="button"
                  key={w}
                  onClick={() => {
                    soundFx.playInteract();
                    onSetWeather(w);
                  }}
                  className={`flex items-center gap-2 p-2 rounded-xl text-xs font-medium border transition ${
                    currentWeather === w
                      ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                      : 'bg-zinc-800/80 hover:bg-zinc-700 border-zinc-700 text-zinc-300'
                  }`}
                >
                  {weatherIcons[w]}
                  <span>{weatherLabels[w]}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Horários Rápidos */}
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">
              Ajustar Horas:
            </span>
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { label: '08:00', hour: 8 },
                { label: '12:00', hour: 12 },
                { label: '16:00', hour: 16 },
                { label: '18:30', hour: 18.5 },
                { label: '21:00', hour: 21 },
                { label: '00:00', hour: 0 },
              ].map((h) => (
                <button
                  type="button"
                  key={h.label}
                  onClick={() => {
                    soundFx.playInteract();
                    onSetTimeOfDay(h.hour);
                  }}
                  className="py-1.5 px-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-lg text-xs font-mono text-zinc-200 transition"
                >
                  {h.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* GUIA DE TECLAS */}
      {showControlsGuide && (
        <div className="absolute top-20 right-4 p-4 bg-zinc-950/95 border border-zinc-700 rounded-xl shadow-2xl text-white pointer-events-auto max-w-xs z-30">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-zinc-800">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">Controlos do Jogo</span>
            <button type="button" onClick={() => setShowControlsGuide(false)} className="text-zinc-400 hover:text-white text-xs">
              ✕
            </button>
          </div>
          <div className="space-y-1.5 text-xs text-zinc-300">
            <div className="flex justify-between"><span className="font-mono text-amber-400">W, A, S, D</span> <span>Mover / Conduzir</span></div>
            <div className="flex justify-between"><span className="font-mono text-amber-400">Shift</span> <span>Correr (A pé)</span></div>
            <div className="flex justify-between"><span className="font-mono text-amber-400">Espaço</span> <span>Saltar / Travão de Mão</span></div>
            <div className="flex justify-between"><span className="font-mono text-amber-400">E</span> <span>Entrar / Sair do Carro / Interagir</span></div>
            <div className="flex justify-between"><span className="font-mono text-amber-400">H</span> <span>Buzinar Bibi! / Alternar HUD</span></div>
            <div className="flex justify-between"><span className="font-mono text-amber-400">Arrastar Rato</span> <span>Câmera 360°</span></div>
          </div>
        </div>
      )}

      {/* 2. HUD DE CONDUÇÃO DE VEÍCULO (SE ESTIVER A CONDUZIR O CANDONGUEIRO) */}
      {isDriving && (
        <div className="pointer-events-auto mx-auto mb-2 px-5 py-2.5 bg-blue-950/95 border-2 border-blue-400 rounded-2xl shadow-2xl flex items-center gap-5 text-white animate-in slide-in-from-bottom duration-200">
          <div className="flex items-center gap-2">
            <Car size={20} className="text-blue-300" />
            <div>
              <div className="text-xs font-black uppercase text-blue-200">Candongueiro Conduzível</div>
              <div className="text-[11px] text-zinc-300">W/S: Acelerar/Ré • A/D: Virar • Espaço: Travar</div>
            </div>
          </div>

          <button
            type="button"
            onClick={onToggleDrive}
            className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs uppercase tracking-wider rounded-xl transition shadow"
          >
            Sair do Veículo [E]
          </button>
        </div>
      )}

      {/* 3. PROMPT DE INTERAÇÃO CONTEXTUAL (Aparece ao aproximar de candongueiro, ATM, comida) */}
      <div className="flex-1 flex items-center justify-center pointer-events-none">
        {!isDriving && nearInteractable && (
          <div className="pointer-events-auto bg-zinc-950/95 border-2 border-amber-500 rounded-2xl p-4 shadow-2xl text-center max-w-md">
            <span className="inline-block px-3 py-1 bg-amber-500 text-zinc-950 font-black text-xs rounded-lg mb-2 shadow">
              PRESSIONE [ E ] PARA INTERAGIR
            </span>
            <h3 className="text-base font-bold text-white">{nearInteractable.title}</h3>
            <p className="text-xs text-zinc-300 mt-1">{nearInteractable.subtitle}</p>

            <button
              type="button"
              onClick={onInteract}
              className="mt-3 px-5 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-bold text-xs uppercase tracking-wider rounded-xl transition shadow-lg inline-flex items-center gap-2"
            >
              <span>{nearInteractable.prompt}</span>
            </button>
          </div>
        )}
      </div>

      {/* 4. CONTROLOS TOUCH PARA DISPOSITIVOS ANDROID / MÓVEIS */}
      {isTouchDevice && (
        <div className="w-full px-6 pb-20 flex items-end justify-between pointer-events-none z-20">
          {/* D-Pad Virtual de Movimentação */}
          <div className="pointer-events-auto grid grid-cols-3 gap-1.5 w-36 h-36 p-1 bg-zinc-950/80 border-2 border-zinc-700 rounded-full items-center justify-center">
            <div />
            <button
              type="button"
              onTouchStart={() => onTouchAction && onTouchAction('forward')}
              className="w-10 h-10 rounded-lg bg-zinc-800 active:bg-amber-500 font-bold text-xs text-white"
            >
              ▲
            </button>
            <div />
            <button
              type="button"
              onTouchStart={() => onTouchAction && onTouchAction('left')}
              className="w-10 h-10 rounded-lg bg-zinc-800 active:bg-amber-500 font-bold text-xs text-white"
            >
              ◀
            </button>
            <div className="flex items-center justify-center text-[10px] text-zinc-500 font-bold">DIR</div>
            <button
              type="button"
              onTouchStart={() => onTouchAction && onTouchAction('right')}
              className="w-10 h-10 rounded-lg bg-zinc-800 active:bg-amber-500 font-bold text-xs text-white"
            >
              ▶
            </button>
            <div />
            <button
              type="button"
              onTouchStart={() => onTouchAction && onTouchAction('backward')}
              className="w-10 h-10 rounded-lg bg-zinc-800 active:bg-amber-500 font-bold text-xs text-white"
            >
              ▼
            </button>
            <div />
          </div>

          {/* Botões de Ação Touch */}
          <div className="pointer-events-auto flex flex-col gap-2.5 items-end">
            <button
              type="button"
              onTouchStart={onInteract}
              className="w-14 h-14 rounded-full bg-amber-500 text-zinc-950 font-black text-sm flex items-center justify-center shadow-xl active:scale-90 transition border-2 border-amber-300"
            >
              E
            </button>
            <div className="flex gap-2.5">
              <button
                type="button"
                onTouchStart={() => onTouchAction && onTouchAction('sprint')}
                className="w-14 h-14 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center shadow-xl active:scale-90 transition border border-blue-400"
              >
                Sprint
              </button>
              <button
                type="button"
                onTouchStart={() => onTouchAction && onTouchAction('jump')}
                className="w-14 h-14 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shadow-xl active:scale-90 transition border border-emerald-400"
              >
                Salto
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. UNIFIED BOTTOM CONTROL DOCK */}
      <footer className="w-full flex flex-col items-center pb-3 px-4 pointer-events-none">
        <button
          type="button"
          onClick={() => setIsDockCollapsed(!isDockCollapsed)}
          className="pointer-events-auto mb-1 px-3 py-1 bg-zinc-950/90 hover:bg-zinc-900 border border-zinc-800 hover:border-amber-500 text-zinc-300 hover:text-white rounded-t-xl text-xs font-semibold shadow-lg transition flex items-center gap-1.5"
        >
          {isDockCollapsed ? (
            <>
              <ChevronUp size={14} className="text-amber-400" />
              <span>Mostrar Painel [H]</span>
            </>
          ) : (
            <>
              <ChevronDown size={14} className="text-amber-400" />
              <span>Ocultar Painel [H]</span>
            </>
          )}
        </button>

        {!isDockCollapsed && (
          <div className="pointer-events-auto w-full max-w-4xl bg-zinc-950/95 border border-zinc-800 rounded-2xl p-3.5 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-3.5">
            {/* Status Bars: Saúde, Energia, Fome, Sede */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full md:w-auto">
              {/* Saúde */}
              <div className="min-w-[110px]">
                <div className="flex justify-between items-center text-[11px] font-bold text-zinc-300 mb-1">
                  <span className="flex items-center gap-1 text-red-400">
                    <Heart size={12} /> Vida
                  </span>
                  <span>{Math.round(stats.health)}%</span>
                </div>
                <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-red-500 rounded-full transition-all duration-300"
                    style={{ width: `${stats.health}%` }}
                  />
                </div>
              </div>

              {/* Energia */}
              <div className="min-w-[110px]">
                <div className="flex justify-between items-center text-[11px] font-bold text-zinc-300 mb-1">
                  <span className="flex items-center gap-1 text-amber-400">
                    <Zap size={12} /> Energia
                  </span>
                  <span>{Math.round(stats.energy)}%</span>
                </div>
                <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-amber-500 rounded-full transition-all duration-300"
                    style={{ width: `${stats.energy}%` }}
                  />
                </div>
              </div>

              {/* Fome */}
              <div className="min-w-[110px]">
                <div className="flex justify-between items-center text-[11px] font-bold text-zinc-300 mb-1">
                  <span className="flex items-center gap-1 text-orange-400">
                    <Utensils size={12} /> Fome
                  </span>
                  <span>{Math.round(stats.hunger)}%</span>
                </div>
                <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-orange-500 rounded-full transition-all duration-300"
                    style={{ width: `${stats.hunger}%` }}
                  />
                </div>
              </div>

              {/* Sede */}
              <div className="min-w-[110px]">
                <div className="flex justify-between items-center text-[11px] font-bold text-zinc-300 mb-1">
                  <span className="flex items-center gap-1 text-cyan-400">
                    <Droplet size={12} /> Sede
                  </span>
                  <span>{Math.round(stats.thirst)}%</span>
                </div>
                <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-cyan-500 rounded-full transition-all duration-300"
                    style={{ width: `${stats.thirst}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="hidden md:block w-px h-9 bg-zinc-800" />

            {/* Ações Rápidas */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={onOpenIdentity}
                className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-200 hover:text-white rounded-xl text-xs font-semibold transition flex items-center gap-1.5"
              >
                <User size={15} className="text-amber-400" />
                <span>Cidadão & Calças</span>
              </button>

              <button
                type="button"
                onClick={onOpenAtm}
                className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-200 hover:text-white rounded-xl text-xs font-semibold transition flex items-center gap-1.5"
              >
                <CreditCard size={15} className="text-emerald-400" />
                <span>Multicaixa</span>
              </button>

              <button
                type="button"
                onClick={onOpenMap}
                className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-200 hover:text-white rounded-xl text-xs font-semibold transition flex items-center gap-1.5"
              >
                <Map size={15} className="text-blue-400" />
                <span>Mapa</span>
              </button>

              <button
                type="button"
                onClick={() => soundFx.toggleRadio()}
                className={`px-3 py-2 border rounded-xl text-xs font-semibold transition flex items-center gap-1.5 ${
                  isRadioOn
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                    : 'bg-zinc-800 hover:bg-zinc-700 border-zinc-700 text-zinc-300 hover:text-white'
                }`}
              >
                <Radio size={15} className={isRadioOn ? 'text-amber-400' : 'text-zinc-400'} />
                <span>{isRadioOn ? 'Rádio On' : 'Rádio'}</span>
              </button>
            </div>
          </div>
        )}
      </footer>
    </div>
  );
};
